package com.example

import com.example.data.remote.WebsiteNoticeParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WebsiteNoticeParserTest {

    @Test
    fun `generic homepage html with notice sections yields no false notices`() {
        val html = """
            <html>
              <body>
                <section id="notices">
                  <h2>Latest Circulars &amp; Holiday Verification</h2>
                  <div class="notice-card">
                    <h3>NJS Public School Digital Portal</h3>
                    <p>Check daily holiday verification and ask our AI School Assistant.</p>
                  </div>
                </section>
              </body>
            </html>
        """.trimIndent()

        val parsed = WebsiteNoticeParser.parseHtmlNotices(html, "https://njspublicschool.pages.dev")
        assertTrue(parsed.isEmpty())
    }

    @Test
    fun `explicit school-notices-data script json extracts notices cleanly`() {
        val html = """
            <html>
              <body>
                <script id="school-notices-data" type="application/json">
                  [
                    {
                      "title": "Winter Timing Revision",
                      "description": "Classes will start at 9:00 AM from Monday due to cold wave.",
                      "attachmentUrl": "/circulars/winter.pdf"
                    }
                  ]
                </script>
              </body>
            </html>
        """.trimIndent()

        val parsed = WebsiteNoticeParser.parseHtmlNotices(html, "https://njspublicschool.pages.dev")
        assertEquals(1, parsed.size)
        assertEquals("Winter Timing Revision", parsed.first().title)
        assertEquals("website", parsed.first().authorId)
        assertEquals("https://njspublicschool.pages.dev/circulars/winter.pdf", parsed.first().attachmentUrl)
    }

    @Test
    fun `rtdb map json parses notices cleanly`() {
        val rtdbJson = """
            {
              "-NxAbc123": {
                "title": "Annual Sports Day Holiday Notice",
                "description": "School remains closed tomorrow following Sports Day celebrations.",
                "noticeDate": "2026-11-18",
                "pinned": true
              }
            }
        """.trimIndent()

        val parsed = WebsiteNoticeParser.parseJsonNotices(rtdbJson, "https://njspublicschool.pages.dev")
        assertEquals(1, parsed.size)
        assertEquals("web_-NxAbc123", parsed.first().id)
        assertEquals("Holiday", parsed.first().category)
        assertTrue(parsed.first().pinned)
    }

    @Test
    fun `backend hints discover rtdb url and firestore projectId`() {
        val jsSnippet = """
            const firebaseConfig = {
              projectId: "njs-school-live",
              databaseURL: "https://njs-school-live-default-rtdb.firebaseio.com"
            };
        """.trimIndent()

        val hints = WebsiteNoticeParser.discoverBackendHints(jsSnippet, "https://njspublicschool.pages.dev")
        assertTrue(hints.rtdbUrls.contains("https://njs-school-live-default-rtdb.firebaseio.com"))
        assertTrue(hints.firestoreProjectIds.contains("njs-school-live"))
    }
}
