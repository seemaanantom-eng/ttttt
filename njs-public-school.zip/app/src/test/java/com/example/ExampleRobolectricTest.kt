package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.SchoolContentCatalog
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NJS Public School", appName)
    assertEquals("9548576481", context.getString(R.string.school_contact_phone))
    assertEquals("Behjadka, Niloha, Mawana, Meerut", context.getString(R.string.school_address))
    assertEquals("9548576481", SchoolContentCatalog.CONTACT_PHONE)
    assertEquals("Behjadka, Niloha, Mawana, Meerut", SchoolContentCatalog.SCHOOL_ADDRESS)
  }
}
