package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val NjsLightColorScheme = lightColorScheme(
    primary = SchoolNavy,
    onPrimary = SchoolPureWhite,
    primaryContainer = SchoolSkyMist,
    onPrimaryContainer = SchoolNavy,
    secondary = SchoolAcademicBlue,
    onSecondary = SchoolPureWhite,
    secondaryContainer = Color(0xFFDCE9FA),
    onSecondaryContainer = SchoolNavy,
    tertiary = SchoolTorchGold,
    onTertiary = SchoolPureWhite,
    tertiaryContainer = SchoolGoldSoft,
    onTertiaryContainer = SchoolGoldDarkText,
    background = SchoolIceSurface,
    onBackground = SchoolInkDark,
    surface = SchoolPureWhite,
    onSurface = SchoolInkDark,
    surfaceVariant = SchoolSkyMist,
    onSurfaceVariant = SchoolInkMuted,
    outline = SchoolBorderBlue,
    outlineVariant = Color(0xFFE2EBF7),
    error = SchoolAlertRed,
    onError = SchoolPureWhite,
    errorContainer = SchoolAlertSoft,
    onErrorContainer = SchoolAlertRed
)

private val NjsDarkColorScheme = darkColorScheme(
    primary = SchoolDarkBluePrimary,
    onPrimary = SchoolDarkOnPrimary,
    primaryContainer = SchoolAcademicBlue,
    onPrimaryContainer = SchoolPureWhite,
    secondary = Color(0xFF6BA4EE),
    onSecondary = SchoolDarkOnPrimary,
    secondaryContainer = SchoolDarkSurfaceHigh,
    onSecondaryContainer = Color(0xFFD6E6FA),
    tertiary = SchoolTorchGold,
    onTertiary = Color(0xFF2B1C00),
    tertiaryContainer = Color(0xFF4F3804),
    onTertiaryContainer = Color(0xFFFFE09B),
    background = SchoolDarkBg,
    onBackground = Color(0xFFEBF2FC),
    surface = SchoolDarkSurface,
    onSurface = Color(0xFFEBF2FC),
    surfaceVariant = SchoolDarkSurfaceHigh,
    onSurfaceVariant = Color(0xFFB3C6E0),
    outline = SchoolDarkOutline,
    outlineVariant = Color(0xFF213654),
    error = Color(0xFFFCA5A5),
    onError = Color(0xFF5C0B0B),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2)
)

val NjsShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NjsSchoolTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> NjsDarkColorScheme
        else -> NjsLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NjsTypography,
        shapes = NjsShapes,
        content = content
    )
}
