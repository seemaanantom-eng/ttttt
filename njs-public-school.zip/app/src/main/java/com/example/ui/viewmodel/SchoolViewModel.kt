package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Notice
import com.example.data.model.SchoolInquiry
import com.example.data.preferences.ThemePreferencesRepository
import com.example.data.preferences.WebsiteSyncMeta
import com.example.data.remote.SchoolRepository
import com.example.data.remote.WebsiteNoticeSyncEngine
import com.example.notifications.WebsiteNotificationHelper
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
class SchoolViewModel(
    private val appContext: Context,
    private val repository: SchoolRepository,
    private val preferences: ThemePreferencesRepository,
    private val currentUserId: String?,
    private val websiteSyncEngine: WebsiteNoticeSyncEngine = WebsiteNoticeSyncEngine(appContext)
) : ViewModel() {

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _isSyncingWebsite = MutableStateFlow(false)
    val isSyncingWebsite: StateFlow<Boolean> = _isSyncingWebsite.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val websiteSyncMeta: StateFlow<WebsiteSyncMeta> = preferences.websiteSyncMeta
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = WebsiteSyncMeta()
        )

    init {
        if (!currentUserId.isNullOrBlank()) {
            viewModelScope.launch {
                _isAdmin.value = repository.checkAdminPrivilege(currentUserId)
            }
        }
        startForegroundWebsiteAutoSync()
    }

    private fun startForegroundWebsiteAutoSync() {
        viewModelScope.launch {
            preferences.clearStaleWebsiteNoticesOnce()
            while (isActive) {
                syncWebsiteNotices(userInitiated = false)
                delay(FOREGROUND_SYNC_INTERVAL_MS)
            }
        }
    }

    fun syncWebsiteNow(userInitiated: Boolean = true) {
        viewModelScope.launch {
            syncWebsiteNotices(userInitiated = userInitiated)
        }
    }

    private suspend fun syncWebsiteNotices(userInitiated: Boolean) {
        if (_isSyncingWebsite.value) return
        _isSyncingWebsite.value = true
        try {
            val result = websiteSyncEngine.syncFromWebsite(allowWebViewFallback = true)
            val newlyDiscovered = preferences.saveWebsiteSyncResult(
                notices = result.notices,
                success = result.success
            )
            if (newlyDiscovered.isNotEmpty()) {
                if (preferences.areWebsiteAlertsEnabled()) {
                    WebsiteNotificationHelper.showNewNoticesNotification(
                        context = appContext,
                        newNotices = newlyDiscovered
                    )
                }
                val count = newlyDiscovered.size
                _feedbackMessage.value = if (count == 1) {
                    "New website notice: ${newlyDiscovered.first().title}"
                } else {
                    "$count new notices synced from njspublicschool.pages.dev"
                }
            } else if (userInitiated) {
                _feedbackMessage.value = when {
                    !result.success -> "Could not reach website. Showing last synced status."
                    result.notices.isEmpty() -> "Website checked: No active notices (School is Open)."
                    else -> "Website notices are up to date (${result.notices.size})."
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Website sync failed", e)
            if (userInitiated) {
                _feedbackMessage.value = "Website sync failed. Check internet connection."
            }
        } finally {
            _isSyncingWebsite.value = false
        }
    }

    fun setWebsiteAlertsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferences.setWebsiteAlertsEnabled(enabled)
            _feedbackMessage.value = if (enabled) {
                "Website notice notifications enabled."
            } else {
                "Website notice notifications muted."
            }
        }
    }

    /**
     * Combines automatically synced notices from njspublicschool.pages.dev with live Firestore
     * notices when signed in. If neither source has notices, emits emptyList() so the UI displays
     * "SCHOOL IS OPEN".
     */
    private val cloudNoticesFlow = _isAdmin
        .flatMapLatest { admin ->
            if (currentUserId.isNullOrBlank()) {
                flowOf(emptyList())
            } else {
                repository.observeNotices(isAdmin = admin)
            }
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing cloud notices", firestoreError ?: error)
            emit(emptyList())
        }

    val noticesState: StateFlow<UiState<List<Notice>>> = combine(
        preferences.websiteNotices,
        cloudNoticesFlow
    ) { websiteList, cloudList ->
        val merged = (cloudList + websiteList)
            .distinctBy { notice ->
                "${notice.title.trim().lowercase()}|${notice.noticeDate.trim().lowercase()}"
            }
            .sortedWith(
                compareByDescending<Notice> { it.pinned }
                    .thenByDescending { it.createdAt ?: Timestamp(0, 0) }
            )
        UiState.Success(merged) as UiState<List<Notice>>
    }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Success(emptyList())
        )

    val inquiriesState: StateFlow<UiState<List<SchoolInquiry>>> = _isAdmin
        .flatMapLatest { admin ->
            if (currentUserId.isNullOrBlank()) {
                preferences.localInquiries
            } else {
                repository.observeInquiries(userId = currentUserId, isAdmin = admin)
            }
        }
        .map<List<SchoolInquiry>, UiState<List<SchoolInquiry>>> { items ->
            val sorted = items.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            UiState.Success(sorted)
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing inquiries", rootError)
            emit(UiState.Error(rootError.message ?: "Unable to load submissions right now."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun showFeedback(message: String) {
        _feedbackMessage.value = message
    }

    fun saveNotice(
        editingNoticeId: String?,
        title: String,
        description: String,
        category: String,
        noticeDate: String,
        pinned: Boolean,
        status: String,
        imageUrl: String?,
        attachmentUrl: String?,
        attachmentLabel: String?,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val result = if (editingNoticeId.isNullOrBlank()) {
                repository.publishNotice(
                    title = title,
                    description = description,
                    category = category,
                    noticeDate = noticeDate,
                    pinned = pinned,
                    status = status,
                    imageUrl = imageUrl,
                    attachmentUrl = attachmentUrl,
                    attachmentLabel = attachmentLabel
                )
            } else {
                repository.updateNotice(
                    noticeId = editingNoticeId,
                    title = title,
                    description = description,
                    category = category,
                    noticeDate = noticeDate,
                    pinned = pinned,
                    status = status,
                    imageUrl = imageUrl,
                    attachmentUrl = attachmentUrl,
                    attachmentLabel = attachmentLabel
                )
            }
            _isSubmitting.value = false
            result.onSuccess {
                _feedbackMessage.value = if (editingNoticeId.isNullOrBlank()) {
                    "School notice published."
                } else {
                    "School notice updated."
                }
                onComplete()
            }.onFailure { err ->
                _feedbackMessage.value = err.message ?: "Could not save notice."
            }
        }
    }

    fun deleteNotice(noticeId: String) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val result = repository.deleteNotice(noticeId)
            _isSubmitting.value = false
            result.onSuccess {
                _feedbackMessage.value = "Notice removed."
            }.onFailure { err ->
                _feedbackMessage.value = err.message ?: "Unable to delete notice."
            }
        }
    }

    fun submitInquiry(
        inquiryType: String,
        senderName: String,
        senderEmail: String,
        contactPhone: String,
        studentName: String?,
        gradeLevel: String?,
        subject: String,
        message: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            if (currentUserId.isNullOrBlank()) {
                preferences.addLocalInquiry(
                    SchoolInquiry(
                        id = "local_${UUID.randomUUID()}",
                        userId = "visitor",
                        inquiryType = inquiryType.trim(),
                        senderName = senderName.trim(),
                        senderEmail = senderEmail.trim().ifEmpty { "Not provided" },
                        contactPhone = contactPhone.trim(),
                        studentName = studentName?.trim()?.takeIf { it.isNotEmpty() },
                        gradeLevel = gradeLevel?.trim()?.takeIf { it.isNotEmpty() },
                        subject = subject.trim(),
                        message = message.trim(),
                        status = "submitted"
                    )
                )
                _isSubmitting.value = false
                _feedbackMessage.value = if (inquiryType == "admission") {
                    "Admission inquiry saved."
                } else {
                    "Message saved to your submissions."
                }
                onComplete()
            } else {
                val result = repository.submitInquiry(
                    inquiryType = inquiryType,
                    senderName = senderName,
                    senderEmail = senderEmail,
                    contactPhone = contactPhone,
                    studentName = studentName,
                    gradeLevel = gradeLevel,
                    subject = subject,
                    message = message
                )
                _isSubmitting.value = false
                result.onSuccess {
                    _feedbackMessage.value = if (inquiryType == "admission") {
                        "Admission inquiry submitted successfully."
                    } else {
                        "Message sent to NJS Public School."
                    }
                    onComplete()
                }.onFailure { err ->
                    _feedbackMessage.value = err.message ?: "Unable to submit form."
                }
            }
        }
    }

    fun updateInquiryReview(
        inquiryId: String,
        status: String,
        adminReply: String?,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val result = repository.updateInquiryReviewByAdmin(inquiryId, status, adminReply)
            _isSubmitting.value = false
            result.onSuccess {
                _feedbackMessage.value = "Submission status updated."
                onComplete()
            }.onFailure { err ->
                _feedbackMessage.value = err.message ?: "Could not update submission."
            }
        }
    }

    fun deleteInquiry(inquiryId: String) {
        viewModelScope.launch {
            _isSubmitting.value = true
            if (currentUserId.isNullOrBlank() || inquiryId.startsWith("local_")) {
                preferences.deleteLocalInquiry(inquiryId)
                _isSubmitting.value = false
                _feedbackMessage.value = "Submission deleted."
            } else {
                val result = repository.deleteInquiry(inquiryId)
                _isSubmitting.value = false
                result.onSuccess {
                    _feedbackMessage.value = "Submission deleted."
                }.onFailure { err ->
                    _feedbackMessage.value = err.message ?: "Could not delete submission."
                }
            }
        }
    }

    private companion object {
        const val TAG = "SchoolViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
        const val FOREGROUND_SYNC_INTERVAL_MS = 45_000L
    }
}
