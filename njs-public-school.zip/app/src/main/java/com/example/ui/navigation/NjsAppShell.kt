package com.example.ui.navigation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.ContactMail
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Celebration
import androidx.compose.material.icons.outlined.ContactMail
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.SchoolContentCatalog
import com.example.data.preferences.CapturedVisitor
import com.example.data.remote.onGoogleSignInClicked
import com.example.data.remote.signOut
import com.example.ui.components.CategoryPill
import com.example.ui.components.SchoolCrestBadge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.CampusHubScreen
import com.example.ui.screens.CampusLifeScreen
import com.example.ui.screens.ConnectScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.NoticesScreen
import com.example.ui.theme.SchoolGoldDarkText
import com.example.ui.theme.SchoolGoldSoft
import com.example.ui.viewmodel.SchoolAiViewModel
import com.example.ui.viewmodel.SchoolViewModel
import com.example.ui.viewmodel.UiState
import kotlinx.coroutines.launch

private data class BottomTabItem(
    val routePrefix: String,
    val defaultRoute: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private data class DrawerMenuItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NjsAppShell(
    viewModel: SchoolViewModel,
    activeVisitorName: String,
    capturedVisitors: List<CapturedVisitor>,
    isCloudSignedIn: Boolean,
    cloudUserEmail: String,
    isDarkMode: Boolean,
    openNoticesOnStart: Boolean = false,
    onConsumedOpenNotices: () -> Unit = {},
    onToggleDarkMode: () -> Unit,
    onSwitchVisitorName: () -> Unit,
    onSelectVisitorName: (String) -> Unit,
    onClearCapturedVisitors: () -> Unit
) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val aiViewModel: SchoolAiViewModel = viewModel()

    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val isSubmitting by viewModel.isSubmitting.collectAsStateWithLifecycle()
    val isSyncingWebsite by viewModel.isSyncingWebsite.collectAsStateWithLifecycle()
    val websiteSyncMeta by viewModel.websiteSyncMeta.collectAsStateWithLifecycle()
    val noticesState by viewModel.noticesState.collectAsStateWithLifecycle()
    val inquiriesState by viewModel.inquiriesState.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()

    LaunchedEffect(openNoticesOnStart) {
        if (openNoticesOnStart) {
            navController.navigate("notices") {
                launchSingleTop = true
            }
            onConsumedOpenNotices()
        }
    }

    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    val bottomTabs = remember {
        listOf(
            BottomTabItem("home", "home", "Home", Icons.Filled.Home, Icons.Outlined.Home, "bottom_nav_home"),
            BottomTabItem("notices", "notices", "Notices", Icons.Filled.Campaign, Icons.Outlined.Campaign, "bottom_nav_notices"),
            BottomTabItem("campus", "campus/0", "School", Icons.Filled.AccountBalance, Icons.Outlined.AccountBalance, "bottom_nav_campus"),
            BottomTabItem("life", "life/0", "Life", Icons.Filled.Celebration, Icons.Outlined.Celebration, "bottom_nav_life"),
            BottomTabItem("connect", "connect/0", "Connect", Icons.Filled.ContactMail, Icons.Outlined.ContactMail, "bottom_nav_connect")
        )
    }

    val drawerMenuItems = remember {
        listOf(
            DrawerMenuItem("home", "1. Home", Icons.Default.Home),
            DrawerMenuItem("campus/0", "2. About School", Icons.Default.AccountBalance),
            DrawerMenuItem("notices", "3. School Notices", Icons.Default.Campaign),
            DrawerMenuItem("life/0", "4. Events and Activities", Icons.Default.Celebration),
            DrawerMenuItem("life/1", "5. Photo Gallery", Icons.Default.PhotoLibrary),
            DrawerMenuItem("connect/0", "6. Admission Information", Icons.Default.School),
            DrawerMenuItem("connect/1", "7. Contact Us", Icons.Default.ContactMail),
            DrawerMenuItem("campus/1", "8. School Facilities", Icons.AutoMirrored.Filled.DirectionsRun),
            DrawerMenuItem("campus/2", "9. Academic Information", Icons.AutoMirrored.Filled.MenuBook),
            DrawerMenuItem("ai_assistant", "10. AI School Assistant", Icons.Default.AutoAwesome)
        )
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "home"

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = false
            }
            launchSingleTop = true
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SchoolCrestBadge(size = 52.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = SchoolContentCatalog.SCHOOL_NAME,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Visitor: $activeVisitorName",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (isAdmin) {
                        Row(modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                            CategoryPill(
                                label = "Verified School Admin",
                                containerColor = SchoolGoldSoft,
                                contentColor = SchoolGoldDarkText
                            )
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                    drawerMenuItems.forEach { item ->
                        NavigationDrawerItem(
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label) },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                navigateTo(item.route)
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                        label = { Text("Enter / Switch Name") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onSwitchVisitorName()
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                    )
                    if (!isCloudSignedIn) {
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = null) },
                            label = { Text("Admin Cloud Access (Optional)") },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                onGoogleSignInClicked(
                                    context = context,
                                    credentialManager = credentialManager,
                                    onAuthSuccess = {
                                        viewModel.showFeedback("Cloud admin session connected.")
                                    },
                                    onAuthError = { msg ->
                                        viewModel.showFeedback(msg)
                                    },
                                    scope = scope,
                                    onAuthCancelled = {
                                        viewModel.showFeedback("Admin sign-in cancelled.")
                                    }
                                )
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    } else {
                        NavigationDrawerItem(
                            icon = {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            },
                            label = { Text("Disconnect Admin Cloud", color = MaterialTheme.colorScheme.error) },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                signOut(credentialManager, scope) {
                                    viewModel.showFeedback("Disconnected cloud admin session.")
                                }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    CenterAlignedTopAppBar(
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        navigationIcon = {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.testTag("menu_drawer_button")
                            ) {
                                Icon(Icons.Default.Menu, contentDescription = "Open navigation menu")
                            }
                        },
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SchoolCrestBadge(size = 32.dp)
                                Text(
                                    text = SchoolContentCatalog.SCHOOL_SHORT_NAME,
                                    style = MaterialTheme.typography.titleLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { navigateTo("ai_assistant") },
                                modifier = Modifier.testTag("open_ai_assistant_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Open AI School Assistant",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = onSwitchVisitorName,
                                modifier = Modifier.testTag("switch_name_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PersonAdd,
                                    contentDescription = "Enter or switch visitor name"
                                )
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            bottomTabs.forEach { tab ->
                                val selected = currentRoute.startsWith(tab.routePrefix)
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTo(tab.defaultRoute) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label, maxLines = 1) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            Spacer(modifier = Modifier.height(12.dp))
                            bottomTabs.forEach { tab ->
                                val selected = currentRoute.startsWith(tab.routePrefix)
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(tab.defaultRoute) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.weight(1f)
                    ) {
                        composable("home") {
                            HomeDashboardScreen(
                                userDisplayName = activeVisitorName,
                                capturedVisitors = capturedVisitors,
                                isAdmin = isAdmin,
                                noticesState = noticesState,
                                websiteSyncMeta = websiteSyncMeta,
                                isSyncingWebsite = isSyncingWebsite,
                                onSyncWebsiteNow = { viewModel.syncWebsiteNow(userInitiated = true) },
                                onToggleWebsiteAlerts = viewModel::setWebsiteAlertsEnabled,
                                onNavigateToRoute = { route -> navigateTo(route) },
                                onAskAi = { query ->
                                    val liveNotices = (noticesState as? UiState.Success)?.data
                                        ?.filter { it.status == "published" }
                                        ?: emptyList()
                                    if (query.isNotBlank()) {
                                        aiViewModel.askQuestion(query, activeVisitorName, liveNotices)
                                    }
                                    navigateTo("ai_assistant")
                                },
                                onSwitchVisitorName = onSwitchVisitorName,
                                onSelectVisitorName = onSelectVisitorName,
                                onClearCapturedVisitors = onClearCapturedVisitors
                            )
                        }
                        composable("notices") {
                            NoticesScreen(
                                noticesState = noticesState,
                                websiteSyncMeta = websiteSyncMeta,
                                isSyncingWebsite = isSyncingWebsite,
                                onSyncWebsiteNow = { viewModel.syncWebsiteNow(userInitiated = true) },
                                onToggleWebsiteAlerts = viewModel::setWebsiteAlertsEnabled,
                                isAdmin = isAdmin,
                                isSubmitting = isSubmitting,
                                selectedCategory = selectedCategory,
                                searchQuery = searchQuery,
                                onCategorySelected = viewModel::setSelectedCategory,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onSaveNotice = viewModel::saveNotice,
                                onDeleteNotice = viewModel::deleteNotice
                            )
                        }
                        composable(
                            route = "campus/{tab}",
                            arguments = listOf(navArgument("tab") { type = NavType.IntType })
                        ) { entry ->
                            val tab = entry.arguments?.getInt("tab") ?: 0
                            CampusHubScreen(initialTab = tab)
                        }
                        composable(
                            route = "life/{tab}",
                            arguments = listOf(navArgument("tab") { type = NavType.IntType })
                        ) { entry ->
                            val tab = entry.arguments?.getInt("tab") ?: 0
                            CampusLifeScreen(initialTab = tab)
                        }
                        composable(
                            route = "connect/{tab}",
                            arguments = listOf(navArgument("tab") { type = NavType.IntType })
                        ) { entry ->
                            val tab = entry.arguments?.getInt("tab") ?: 0
                            ConnectScreen(
                                initialTab = tab,
                                userDisplayName = activeVisitorName,
                                userEmail = cloudUserEmail,
                                isAdmin = isAdmin,
                                isSubmitting = isSubmitting,
                                inquiriesState = inquiriesState,
                                onSubmitInquiry = viewModel::submitInquiry,
                                onAdminReviewInquiry = viewModel::updateInquiryReview,
                                onDeleteInquiry = viewModel::deleteInquiry
                            )
                        }
                        composable("ai_assistant") {
                            val liveNotices = (noticesState as? UiState.Success)?.data
                                ?.filter { it.status == "published" }
                                ?: emptyList()
                            AiAssistantScreen(
                                aiViewModel = aiViewModel,
                                visitorName = activeVisitorName,
                                activeNotices = liveNotices
                            )
                        }
                    }
                }
            }
        }
    }
}
