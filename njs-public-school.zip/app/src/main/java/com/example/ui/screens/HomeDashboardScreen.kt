package com.example.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContactMail
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Notice
import com.example.data.model.SchoolContentCatalog
import com.example.data.preferences.CapturedVisitor
import com.example.data.preferences.WebsiteSyncMeta
import com.example.ui.components.CategoryPill
import com.example.ui.components.NoticeDetailDialog
import com.example.ui.components.PortalActionCard
import com.example.ui.components.SchoolCrestBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.WebsiteSyncStatusBar
import com.example.ui.theme.SchoolAcademicBlue
import com.example.ui.theme.SchoolAlertRed
import com.example.ui.theme.SchoolAlertSoft
import com.example.ui.theme.SchoolGoldDarkText
import com.example.ui.theme.SchoolGoldSoft
import com.example.ui.theme.SchoolNavy
import com.example.ui.theme.SchoolPureWhite
import com.example.ui.theme.SchoolSuccessGreen
import com.example.ui.theme.SchoolSuccessSoft
import com.example.ui.theme.SchoolTorchGold
import com.example.ui.viewmodel.UiState

data class QuickAccessItem(
    val route: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val testTag: String
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeDashboardScreen(
    userDisplayName: String,
    capturedVisitors: List<CapturedVisitor>,
    isAdmin: Boolean,
    noticesState: UiState<List<Notice>>,
    websiteSyncMeta: WebsiteSyncMeta,
    isSyncingWebsite: Boolean,
    onSyncWebsiteNow: () -> Unit,
    onToggleWebsiteAlerts: (Boolean) -> Unit,
    onNavigateToRoute: (String) -> Unit,
    onAskAi: (String) -> Unit = { onNavigateToRoute("ai_assistant") },
    onSwitchVisitorName: () -> Unit,
    onSelectVisitorName: (String) -> Unit,
    onClearCapturedVisitors: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedNotice by remember { mutableStateOf<Notice?>(null) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var aiSearchQuery by rememberSaveable { mutableStateOf("") }
    var cardsEntered by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        cardsEntered = true
    }

    fun submitDashboardAiSearch(query: String = aiSearchQuery) {
        val clean = query.trim()
        keyboardController?.hide()
        if (clean.isNotEmpty()) {
            aiSearchQuery = ""
            onAskAi(clean)
        } else {
            onNavigateToRoute("ai_assistant")
        }
    }

    val quickAiSuggestions = remember {
        listOf(
            "Is school open today?",
            "Latest school notices",
            "Sports & campus facilities",
            "Hastinapur excursion",
            "Admission info"
        )
    }

    val quickAccessItems = remember {
        listOf(
            QuickAccessItem("notices", "School Notices", "Circulars & updates", Icons.Default.Campaign, "qa_notices"),
            QuickAccessItem("campus/0", "About School", "Vision & heritage", Icons.Default.AccountBalance, "qa_about"),
            QuickAccessItem("campus/1", "School Facilities", "400m track & studios", Icons.AutoMirrored.Filled.DirectionsRun, "qa_facilities"),
            QuickAccessItem("campus/2", "Academic Info", "Mentorship & portal", Icons.AutoMirrored.Filled.MenuBook, "qa_academics"),
            QuickAccessItem("life/0", "Events & Activities", "Festivals & trips", Icons.Default.Celebration, "qa_events"),
            QuickAccessItem("life/1", "Photo Gallery", "Campus highlights", Icons.Default.PhotoLibrary, "qa_gallery"),
            QuickAccessItem("connect/0", "Admissions", "Enroll & inquire", Icons.Default.School, "qa_admissions"),
            QuickAccessItem("connect/1", "Contact Us", "Reach school desk", Icons.Default.ContactMail, "qa_contact")
        )
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Welcome Hero Card with Uploaded School Logo, School Name & Visitor Greeting
            item {
                StaggeredDashboardEntry(index = 0, visible = cardsEntered) {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = SchoolNavy),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_campus),
                            contentDescription = "NJS Public School Campus Banner",
                            contentScale = ContentScale.Crop,
                            alpha = 0.28f,
                            modifier = Modifier.matchParentSize()
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            SchoolNavy.copy(alpha = 0.94f),
                                            SchoolAcademicBlue.copy(alpha = 0.78f)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                SchoolCrestBadge(size = 58.dp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = SchoolContentCatalog.SCHOOL_NAME,
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = SchoolPureWhite
                                    )
                                    Text(
                                        text = SchoolContentCatalog.MOTTO,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color(0xFFFFE199)
                                    )
                                }
                                if (isAdmin) {
                                    CategoryPill(
                                        label = "Admin",
                                        containerColor = SchoolTorchGold,
                                        contentColor = SchoolNavy
                                    )
                                }
                            }
                            Text(
                                text = "Welcome, ${userDisplayName.ifBlank { "Guest" }}!",
                                style = MaterialTheme.typography.headlineSmall,
                                color = SchoolPureWhite,
                                modifier = Modifier.testTag("dashboard_greeting_name")
                            )
                            Text(
                                text = "Explore school notices, AI School Assistant, facilities, campus events, photo gallery, and inquiries.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SchoolPureWhite.copy(alpha = 0.88f)
                            )
                            Button(
                                onClick = { onNavigateToRoute("ai_assistant") },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SchoolTorchGold,
                                    contentColor = SchoolNavy
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("hero_ask_ai_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Ask AI School Assistant",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    }
                }
            }

            // 2. Aesthetic AI Search Bar Card — search & ask NJS AI directly from Dashboard
            item {
                StaggeredDashboardEntry(index = 1, visible = cardsEntered) {
                    DashboardAiSearchCard(
                        query = aiSearchQuery,
                        onQueryChange = { aiSearchQuery = it },
                        quickSuggestions = quickAiSuggestions,
                        onSubmitSearch = { submitDashboardAiSearch() },
                        onSuggestionClick = { suggestion -> submitDashboardAiSearch(suggestion) }
                    )
                }
            }

            // 3. Notice Board / School Status Banner:
            // Shows added notices if any exist; otherwise displays "SCHOOL IS OPEN" in big bold letters!
            item {
                StaggeredDashboardEntry(index = 2, visible = cardsEntered) {
                    Column(
                        modifier = Modifier.animateContentSize(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            SectionHeader(
                                title = "School Notice & Status",
                                subtitle = "Auto-synced from njspublicschool.pages.dev",
                                icon = Icons.Default.Campaign
                            )
                        }
                        TextButton(
                            onClick = { onNavigateToRoute("notices") },
                            modifier = Modifier.testTag("home_view_all_notices")
                        ) {
                            Text("Notices")
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    WebsiteSyncStatusBar(
                        syncMeta = websiteSyncMeta,
                        isSyncing = isSyncingWebsite,
                        onSyncNow = onSyncWebsiteNow,
                        onToggleAlerts = onToggleWebsiteAlerts
                    )

                    when (noticesState) {
                        is UiState.Loading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(28.dp))
                            }
                        }
                        is UiState.Error -> {
                            SchoolStatusBanner(isClosed = false)
                        }
                        is UiState.Success -> {
                            val activeNotices = noticesState.data.filter { it.status == "published" }
                            if (activeNotices.isEmpty()) {
                                SchoolStatusBanner(isClosed = false)
                            } else {
                                SchoolStatusBanner(
                                    isClosed = true,
                                    noticeCount = activeNotices.size
                                )
                                val pinned = activeNotices.filter { it.pinned }
                                if (pinned.isNotEmpty()) {
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        items(pinned, key = { "pinned_${it.id}" }) { notice ->
                                            Card(
                                                modifier = Modifier
                                                    .width(280.dp)
                                                    .clickable { selectedNotice = notice },
                                                shape = MaterialTheme.shapes.medium,
                                                colors = CardDefaults.cardColors(
                                                    containerColor = MaterialTheme.colorScheme.surface
                                                ),
                                                border = BorderStroke(1.5.dp, SchoolTorchGold.copy(alpha = 0.7f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(14.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Row(
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.PushPin,
                                                                contentDescription = null,
                                                                tint = SchoolTorchGold,
                                                                modifier = Modifier.size(15.dp)
                                                            )
                                                            CategoryPill(
                                                                label = notice.category,
                                                                containerColor = SchoolGoldSoft,
                                                                contentColor = SchoolGoldDarkText
                                                            )
                                                        }
                                                        Text(
                                                            text = notice.noticeDate,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    Text(
                                                        text = notice.title,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = notice.description,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 3,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    activeNotices.take(4).forEach { notice ->
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { selectedNotice = notice },
                                            shape = MaterialTheme.shapes.medium,
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.surface
                                            ),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        CategoryPill(label = notice.category)
                                                        if (notice.authorId == "website") {
                                                            CategoryPill(
                                                                label = "Website",
                                                                containerColor = SchoolGoldSoft,
                                                                contentColor = SchoolGoldDarkText
                                                            )
                                                        }
                                                    }
                                                    Text(
                                                        text = notice.noticeDate,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Text(
                                                    text = notice.title,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = notice.description,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 3,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    }
                }
            }

            // 4. Captured Names Registry Card on Dashboard
            item {
                StaggeredDashboardEntry(index = 3, visible = cardsEntered) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness = Spring.StiffnessMediumLow
                                )
                            )
                            .testTag("captured_names_card"),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Groups,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Captured Names",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Active: $userDisplayName • ${capturedVisitors.size} total entries",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            if (capturedVisitors.size > 1) {
                                IconButton(
                                    onClick = { showClearConfirm = true },
                                    modifier = Modifier.testTag("clear_captured_names_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteSweep,
                                        contentDescription = "Clear visitor history",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        if (capturedVisitors.isEmpty()) {
                            Text(
                                text = "Your entered name ($userDisplayName) is active.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                capturedVisitors.forEach { visitor ->
                                    val isActive = visitor.name.equals(userDisplayName, ignoreCase = true)
                                    AssistChip(
                                        onClick = { onSelectVisitorName(visitor.name) },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Badge,
                                                contentDescription = null,
                                                tint = if (isActive) {
                                                    MaterialTheme.colorScheme.primary
                                                } else {
                                                    MaterialTheme.colorScheme.onSurfaceVariant
                                                },
                                                modifier = Modifier.size(16.dp)
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = if (visitor.enteredAt.isNotBlank()) {
                                                    "${visitor.name} (${visitor.enteredAt})"
                                                } else {
                                                    visitor.name
                                                },
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = onSwitchVisitorName,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_visitor_name_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Enter New Name / Switch Visitor")
                        }
                    }
                    }
                }
            }

            // 5. Quick-Access Cards
            item {
                StaggeredDashboardEntry(index = 4, visible = cardsEntered) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader(
                            title = "Quick Access",
                            subtitle = "Explore every section of NJS Public School",
                            icon = Icons.Default.School
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            quickAccessItems.chunked(2).forEach { pair ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    pair.forEach { item ->
                                        QuickAccessCard(
                                            item = item,
                                            onClick = { onNavigateToRoute(item.route) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (pair.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 6. School Information, Contact & Address
            item {
                StaggeredDashboardEntry(index = 5, visible = cardsEntered) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader(
                        title = "School Information",
                        subtitle = "Contact number, campus address, web portal & media",
                        icon = Icons.Default.Language
                    )
                    PortalActionCard(
                        title = "School Contact Number",
                        subtitle = SchoolContentCatalog.CONTACT_PHONE,
                        buttonLabel = "Call",
                        url = SchoolContentCatalog.CONTACT_PHONE_URL,
                        icon = Icons.Default.Phone,
                        modifier = Modifier.testTag("school_contact_phone_card")
                    )
                    PortalActionCard(
                        title = "Campus Address",
                        subtitle = SchoolContentCatalog.SCHOOL_ADDRESS,
                        buttonLabel = "Map",
                        url = SchoolContentCatalog.SCHOOL_MAP_URL,
                        icon = Icons.Default.LocationOn,
                        modifier = Modifier.testTag("school_address_card")
                    )
                    PortalActionCard(
                        title = "NJS Public School Web Portal",
                        subtitle = SchoolContentCatalog.PORTAL_URL,
                        buttonLabel = "Visit",
                        url = SchoolContentCatalog.PORTAL_URL,
                        icon = Icons.Default.Language
                    )
                    PortalActionCard(
                        title = "Official YouTube Updates",
                        subtitle = "School activities & video highlights (${SchoolContentCatalog.YOUTUBE_HANDLE})",
                        buttonLabel = "Watch",
                        url = SchoolContentCatalog.YOUTUBE_URL,
                        icon = Icons.Default.PlayCircle
                    )
                    }
                }
            }
        }
    }

    selectedNotice?.let { notice ->
        NoticeDetailDialog(
            notice = notice,
            isAdmin = false,
            onDismiss = { selectedNotice = null }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Captured Names History?") },
            text = { Text("Remove previously captured visitor entries from this device?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearCapturedVisitors()
                        showClearConfirm = false
                    }
                ) {
                    Text("Clear", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SchoolStatusBanner(
    isClosed: Boolean,
    noticeCount: Int = 0,
    modifier: Modifier = Modifier
) {
    val containerColor = if (isClosed) SchoolAlertSoft else SchoolSuccessSoft
    val accentColor = if (isClosed) SchoolAlertRed else SchoolSuccessGreen
    val badgeIcon = if (isClosed) Icons.Default.Campaign else Icons.Default.CheckCircle
    val badgeLabel = if (isClosed) {
        if (noticeCount > 1) "$noticeCount NOTICES ACTIVE" else "NOTICE ACTIVE"
    } else {
        "NO NEW NOTICES"
    }
    val headlineText = if (isClosed) "SCHOOL IS CLOSE" else "SCHOOL IS OPEN"
    val subtitleText = if (isClosed) {
        "Notice added. Please read the announcement below for details."
    } else {
        "No notice has been posted. Regular school classes and campus activities are open as scheduled."
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag(if (isClosed) "school_close_banner" else "school_open_banner"),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(2.dp, accentColor.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = accentColor.copy(alpha = 0.14f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                    Icon(
                        imageVector = badgeIcon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = badgeLabel,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                }
            }

            Text(
                text = headlineText,
                fontSize = 34.sp,
                lineHeight = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.5.sp,
                color = accentColor,
                textAlign = TextAlign.Center
            )

            Text(
                text = subtitleText,
                style = MaterialTheme.typography.bodyMedium,
                color = SchoolNavy,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun SchoolIsOpenBanner(
    modifier: Modifier = Modifier
) {
    SchoolStatusBanner(isClosed = false, modifier = modifier)
}

@Composable
private fun DashboardAiSearchCard(
    query: String,
    onQueryChange: (String) -> Unit,
    quickSuggestions: List<String>,
    onSubmitSearch: () -> Unit,
    onSuggestionClick: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_ai_search_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .padding(7.dp)
                                .size(16.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Search on NJS AI",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Instant school answers in English & हिन्दी",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                CategoryPill(
                    label = "Fast AI",
                    containerColor = SchoolGoldSoft,
                    contentColor = SchoolGoldDarkText
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = {
                        Text(
                            text = "Search holidays, notices, school info...",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search AI",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(
                                onClick = { onQueryChange("") },
                                modifier = Modifier.testTag("dashboard_ai_search_clear")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear AI search"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSubmitSearch() }),
                    shape = RoundedCornerShape(50),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dashboard_ai_search_input")
                )

                FilledIconButton(
                    onClick = onSubmitSearch,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .size(50.dp)
                        .testTag("dashboard_ai_search_button")
                ) {
                    Icon(
                        imageVector = if (query.isBlank()) {
                            Icons.Default.AutoAwesome
                        } else {
                            Icons.AutoMirrored.Filled.Send
                        },
                        contentDescription = if (query.isBlank()) {
                            "Open AI Assistant"
                        } else {
                            "Search on AI"
                        }
                    )
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickSuggestions) { suggestion ->
                    AssistChip(
                        onClick = { onSuggestionClick(suggestion) },
                        label = {
                            Text(
                                text = suggestion,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        shape = RoundedCornerShape(50),
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickAccessCard(
    item: QuickAccessItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(item.testTag),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(9.dp)
                        .size(20.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun StaggeredDashboardEntry(
    index: Int,
    visible: Boolean,
    content: @Composable () -> Unit
) {
    val delayMs = (index * 55).coerceAtMost(275)
    val offsetPx = with(LocalDensity.current) { 18.dp.toPx() }
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 360, delayMillis = delayMs, easing = FastOutSlowInEasing),
        label = "dashboard_entry_alpha_$index"
    )
    val translationY by animateFloatAsState(
        targetValue = if (visible) 0f else offsetPx,
        animationSpec = tween(durationMillis = 400, delayMillis = delayMs, easing = FastOutSlowInEasing),
        label = "dashboard_entry_translation_$index"
    )
    val scale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.97f,
        animationSpec = tween(durationMillis = 400, delayMillis = delayMs, easing = FastOutSlowInEasing),
        label = "dashboard_entry_scale_$index"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha
                this.translationY = translationY
                this.scaleX = scale
                this.scaleY = scale
            }
    ) {
        content()
    }
}
