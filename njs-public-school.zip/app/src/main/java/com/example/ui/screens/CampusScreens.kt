package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SchoolContentCatalog
import com.example.ui.components.CategoryPill
import com.example.ui.components.PortalActionCard
import com.example.ui.components.SchoolCrestBadge
import com.example.ui.components.SectionHeader

@Composable
fun CampusHubScreen(
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(initialTab.coerceIn(0, 2)) }
    LaunchedEffect(initialTab) {
        selectedTab = initialTab.coerceIn(0, 2)
    }

    val tabs = listOf("About School", "Facilities", "Academics")

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(label, maxLines = 1) },
                        modifier = Modifier.testTag("campus_tab_$index")
                    )
                }
            }

            when (selectedTab) {
                0 -> AboutSchoolContent()
                1 -> SchoolFacilitiesContent()
                else -> AcademicInformationContent()
            }
        }
    }
}

@Composable
private fun AboutSchoolContent() {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "About NJS Public School",
                subtitle = SchoolContentCatalog.MOTTO,
                icon = Icons.Default.AccountBalance
            )
        }
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_campus),
                        contentDescription = "NJS Public School Campus",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(175.dp)
                            .clip(RoundedCornerShape(14.dp))
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SchoolCrestBadge(size = 46.dp)
                        Column {
                            Text(
                                text = SchoolContentCatalog.SCHOOL_NAME,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Motto: ${SchoolContentCatalog.MOTTO}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        text = "NJS Public School is dedicated to delivering educational excellence by blending modern digital campus infrastructure with timeless cultural values, moral mentoring, and regular Havan sessions.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Beyond academics, students actively participate in 400m Olympic-track athletics, turf-pitch cricket and floodlit football academies, terracotta and clay sculpting workshops, eco-friendly festival celebrations, and curated educational excursions such as trips to Hastinapur.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            PortalActionCard(
                title = "School Address",
                subtitle = SchoolContentCatalog.SCHOOL_ADDRESS,
                buttonLabel = "Map",
                url = SchoolContentCatalog.SCHOOL_MAP_URL,
                icon = Icons.Default.LocationOn
            )
        }
        item {
            PortalActionCard(
                title = "Contact Number",
                subtitle = SchoolContentCatalog.CONTACT_PHONE,
                buttonLabel = "Call",
                url = SchoolContentCatalog.CONTACT_PHONE_URL,
                icon = Icons.Default.Phone
            )
        }
        item {
            PortalActionCard(
                title = "Official Web Portal",
                subtitle = SchoolContentCatalog.PORTAL_URL,
                buttonLabel = "Open",
                url = SchoolContentCatalog.PORTAL_URL,
                icon = Icons.Default.Language
            )
        }
        item {
            PortalActionCard(
                title = "Official Media Channel",
                subtitle = "NJS Public School updates on YouTube (${SchoolContentCatalog.YOUTUBE_HANDLE})",
                buttonLabel = "YouTube",
                url = SchoolContentCatalog.YOUTUBE_URL,
                icon = Icons.Default.PlayCircle
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SchoolFacilitiesContent() {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "School Facilities",
                subtitle = "Sports complex, fine arts, and cultural spaces",
                icon = Icons.AutoMirrored.Filled.DirectionsRun
            )
        }
        items(SchoolContentCatalog.facilities) { facility ->
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (facility.imageRes != null) {
                        Image(
                            painter = painterResource(id = facility.imageRes),
                            contentDescription = facility.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(155.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    }
                    Text(
                        text = facility.subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = facility.title,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = facility.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        facility.highlights.forEach { tag ->
                            CategoryPill(label = tag)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AcademicInformationContent() {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Academic Information",
                subtitle = "Mentorship, curriculum approach, and digital circulars",
                icon = Icons.AutoMirrored.Filled.MenuBook
            )
        }
        items(SchoolContentCatalog.academicPrograms) { program ->
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryPill(label = program.badge)
                    Text(
                        text = program.title,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = program.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Exam Timetables & Holiday Verifications",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Published academic calendars, exam schedules, and official holiday circulars appear in real time under School Notices and on njspublicschool.pages.dev.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.88f)
                    )
                }
            }
        }
    }
}
