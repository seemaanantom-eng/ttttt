package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContactMail
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.SchoolContentCatalog
import com.example.data.model.SchoolInquiry
import com.example.ui.components.CategoryPill
import com.example.ui.components.PortalActionCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.SchoolGoldDarkText
import com.example.ui.theme.SchoolGoldSoft
import com.example.ui.theme.SchoolSuccessGreen
import com.example.ui.theme.SchoolSuccessSoft
import com.example.ui.viewmodel.UiState

@Composable
fun ConnectScreen(
    initialTab: Int = 0,
    userDisplayName: String,
    userEmail: String,
    isAdmin: Boolean,
    isSubmitting: Boolean,
    inquiriesState: UiState<List<SchoolInquiry>>,
    onSubmitInquiry: (
        inquiryType: String,
        senderName: String,
        senderEmail: String,
        contactPhone: String,
        studentName: String?,
        gradeLevel: String?,
        subject: String,
        message: String,
        onComplete: () -> Unit
    ) -> Unit,
    onAdminReviewInquiry: (
        inquiryId: String,
        status: String,
        adminReply: String?,
        onComplete: () -> Unit
    ) -> Unit,
    onDeleteInquiry: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(initialTab.coerceIn(0, 2)) }
    LaunchedEffect(initialTab) {
        selectedTab = initialTab.coerceIn(0, 2)
    }

    val tabs = listOf(
        "Admissions",
        "Contact Us",
        if (isAdmin) "Inbox" else "My Requests"
    )

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(label, maxLines = 1) },
                        modifier = Modifier.testTag("connect_tab_$index")
                    )
                }
            }

            when (selectedTab) {
                0 -> AdmissionInformationContent(
                    defaultName = userDisplayName,
                    defaultEmail = userEmail,
                    isSubmitting = isSubmitting,
                    onSubmit = { name, email, phone, student, grade, subject, msg, clear ->
                        onSubmitInquiry("admission", name, email, phone, student, grade, subject, msg) {
                            clear()
                            selectedTab = 2
                        }
                    }
                )
                1 -> ContactUsContent(
                    defaultName = userDisplayName,
                    defaultEmail = userEmail,
                    isSubmitting = isSubmitting,
                    onSubmit = { name, email, phone, subject, msg, clear ->
                        onSubmitInquiry("contact", name, email, phone, null, null, subject, msg) {
                            clear()
                            selectedTab = 2
                        }
                    }
                )
                else -> SubmissionsHistoryContent(
                    inquiriesState = inquiriesState,
                    isAdmin = isAdmin,
                    isSubmitting = isSubmitting,
                    onAdminReview = onAdminReviewInquiry,
                    onDelete = onDeleteInquiry
                )
            }
        }
    }
}

@Composable
private fun AdmissionInformationContent(
    defaultName: String,
    defaultEmail: String,
    isSubmitting: Boolean,
    onSubmit: (
        name: String,
        email: String,
        phone: String,
        studentName: String,
        gradeLevel: String,
        subject: String,
        message: String,
        onClear: () -> Unit
    ) -> Unit
) {
    var parentName by rememberSaveable { mutableStateOf(defaultName) }
    var email by rememberSaveable { mutableStateOf(defaultEmail) }
    var phone by rememberSaveable { mutableStateOf("") }
    var studentName by rememberSaveable { mutableStateOf("") }
    var gradeLevel by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("Admission Inquiry") }
    var notes by rememberSaveable { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Admission Information",
                subtitle = "Enrollment bulletins and direct admission inquiries",
                icon = Icons.Default.School
            )
        }
        item {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Official Admission Guidelines",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Campus: ${SchoolContentCatalog.SCHOOL_ADDRESS} • Helpline: ${SchoolContentCatalog.CONTACT_PHONE}. Admission guidelines and enrollment notices are published on the Notice Board and njspublicschool.pages.dev.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.88f)
                    )
                }
            }
        }
        item {
            PortalActionCard(
                title = "Admissions Helpline",
                subtitle = SchoolContentCatalog.CONTACT_PHONE,
                buttonLabel = "Call",
                url = SchoolContentCatalog.CONTACT_PHONE_URL,
                icon = Icons.Default.Phone
            )
        }
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Admission Inquiry Form",
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedTextField(
                        value = parentName,
                        onValueChange = { parentName = it },
                        label = { Text("Parent / Guardian Name*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = studentName,
                        onValueChange = { studentName = it },
                        label = { Text("Student Name*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = gradeLevel,
                        onValueChange = { gradeLevel = it },
                        label = { Text("Target Class / Grade*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Contact Phone*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Questions or Details*") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!validationError.isNullOrBlank()) {
                        Text(
                            text = validationError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(
                        onClick = {
                            when {
                                parentName.trim().length < 2 -> validationError = "Enter parent/guardian name (min 2 chars)."
                                studentName.trim().isEmpty() -> validationError = "Enter prospective student name."
                                gradeLevel.trim().isEmpty() -> validationError = "Enter target class or grade."
                                phone.trim().length < 5 -> validationError = "Enter a valid contact phone number."
                                email.trim().isNotEmpty() && email.trim().length < 3 -> validationError = "Enter a valid email address."
                                subject.trim().length < 3 -> validationError = "Subject must be at least 3 characters."
                                notes.trim().length < 5 -> validationError = "Please enter at least 5 characters in details."
                                else -> {
                                    validationError = null
                                    val resolvedEmail = email.trim().ifEmpty { "visitor@njspublicschool.local" }
                                    onSubmit(parentName, resolvedEmail, phone, studentName, gradeLevel, subject, notes) {
                                        studentName = ""
                                        gradeLevel = ""
                                        notes = ""
                                    }
                                }
                            }
                        },
                        enabled = !isSubmitting,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_admission_button")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Submit Admission Inquiry")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactUsContent(
    defaultName: String,
    defaultEmail: String,
    isSubmitting: Boolean,
    onSubmit: (
        name: String,
        email: String,
        phone: String,
        subject: String,
        message: String,
        onClear: () -> Unit
    ) -> Unit
) {
    var name by rememberSaveable { mutableStateOf(defaultName) }
    var email by rememberSaveable { mutableStateOf(defaultEmail) }
    var phone by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Contact Us",
                subtitle = "Call, visit campus, or send a direct inquiry",
                icon = Icons.Default.ContactMail
            )
        }
        item {
            PortalActionCard(
                title = "Contact Number",
                subtitle = SchoolContentCatalog.CONTACT_PHONE,
                buttonLabel = "Call",
                url = SchoolContentCatalog.CONTACT_PHONE_URL,
                icon = Icons.Default.Phone,
                modifier = Modifier.testTag("contact_phone_card")
            )
        }
        item {
            PortalActionCard(
                title = "School Address",
                subtitle = SchoolContentCatalog.SCHOOL_ADDRESS,
                buttonLabel = "Map",
                url = SchoolContentCatalog.SCHOOL_MAP_URL,
                icon = Icons.Default.LocationOn,
                modifier = Modifier.testTag("contact_address_card")
            )
        }
        item {
            PortalActionCard(
                title = "Official School Website",
                subtitle = SchoolContentCatalog.PORTAL_URL,
                buttonLabel = "Visit",
                url = SchoolContentCatalog.PORTAL_URL,
                icon = Icons.Default.Language
            )
        }
        item {
            PortalActionCard(
                title = "Official YouTube Channel",
                subtitle = "School events & announcements (${SchoolContentCatalog.YOUTUBE_HANDLE})",
                buttonLabel = "Open",
                url = SchoolContentCatalog.YOUTUBE_URL,
                icon = Icons.Default.PlayCircle
            )
        }
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Send a Message",
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Your Full Name*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Message*") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!validationError.isNullOrBlank()) {
                        Text(
                            text = validationError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(
                        onClick = {
                            when {
                                name.trim().length < 2 -> validationError = "Enter your full name (min 2 chars)."
                                email.trim().isNotEmpty() && email.trim().length < 3 -> validationError = "Enter a valid email address."
                                phone.trim().length < 5 -> validationError = "Enter a valid contact phone number."
                                subject.trim().length < 3 -> validationError = "Subject must be at least 3 characters."
                                message.trim().length < 5 -> validationError = "Message must be at least 5 characters."
                                else -> {
                                    validationError = null
                                    val resolvedEmail = email.trim().ifEmpty { "visitor@njspublicschool.local" }
                                    onSubmit(name, resolvedEmail, phone, subject, message) {
                                        subject = ""
                                        message = ""
                                    }
                                }
                            }
                        },
                        enabled = !isSubmitting,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_contact_button")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Send Message")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubmissionsHistoryContent(
    inquiriesState: UiState<List<SchoolInquiry>>,
    isAdmin: Boolean,
    isSubmitting: Boolean,
    onAdminReview: (String, String, String?, () -> Unit) -> Unit,
    onDelete: (String) -> Unit
) {
    var reviewingInquiry by remember { mutableStateOf<SchoolInquiry?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = if (isAdmin) "Submissions Inbox" else "My Submissions",
                subtitle = if (isAdmin) {
                    "Review and respond to parent/visitor admission and contact inquiries"
                } else {
                    "Track your admission inquiries and contact messages"
                },
                icon = Icons.Default.Inbox
            )
        }
        when (inquiriesState) {
            is UiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = inquiriesState.message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
            is UiState.Success -> {
                if (inquiriesState.data.isEmpty()) {
                    item {
                        Card(
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Inbox,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "No submissions yet",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Use the Admissions or Contact Us tab to submit an inquiry.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(inquiriesState.data, key = { it.id }) { inquiry ->
                        InquiryCard(
                            inquiry = inquiry,
                            isAdmin = isAdmin,
                            onReviewClick = { reviewingInquiry = inquiry },
                            onDeleteClick = { onDelete(inquiry.id) }
                        )
                    }
                }
            }
        }
    }

    reviewingInquiry?.let { target ->
        AdminReviewDialog(
            inquiry = target,
            isSubmitting = isSubmitting,
            onDismiss = { reviewingInquiry = null },
            onSave = { status, reply ->
                onAdminReview(target.id, status, reply) {
                    reviewingInquiry = null
                }
            }
        )
    }
}

@Composable
private fun InquiryCard(
    inquiry: SchoolInquiry,
    isAdmin: Boolean,
    onReviewClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val (statusContainer, statusContent) = when (inquiry.status) {
        "resolved" -> SchoolSuccessSoft to SchoolSuccessGreen
        "reviewed" -> SchoolGoldSoft to SchoolGoldDarkText
        else -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    }
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CategoryPill(
                        label = if (inquiry.inquiryType == "admission") "Admission" else "Contact"
                    )
                    CategoryPill(
                        label = inquiry.status.replaceFirstChar { it.uppercase() },
                        containerColor = statusContainer,
                        contentColor = statusContent
                    )
                }
                Row {
                    if (isAdmin) {
                        IconButton(onClick = onReviewClick) {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = "Review submission",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(onClick = onDeleteClick) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete submission",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
            Text(text = inquiry.subject, style = MaterialTheme.typography.titleMedium)
            Text(
                text = "From: ${inquiry.senderName} (${inquiry.contactPhone})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!inquiry.studentName.isNullOrBlank()) {
                Text(
                    text = "Student: ${inquiry.studentName} • Grade: ${inquiry.gradeLevel ?: "-"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = inquiry.message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (!inquiry.adminReply.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "School Response",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = inquiry.adminReply,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminReviewDialog(
    inquiry: SchoolInquiry,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String?) -> Unit
) {
    var status by remember { mutableStateOf(inquiry.status) }
    var reply by remember { mutableStateOf(inquiry.adminReply ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update Submission Status") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(inquiry.subject, style = MaterialTheme.typography.titleSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(SchoolContentCatalog.inquiryStatuses) { st ->
                        FilterChip(
                            selected = status == st,
                            onClick = { status = st },
                            label = { Text(st.replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
                OutlinedTextField(
                    value = reply,
                    onValueChange = { reply = it },
                    label = { Text("Admin Reply Note (Optional)") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(status, reply.trim().takeIf { it.isNotEmpty() }) },
                enabled = !isSubmitting
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
