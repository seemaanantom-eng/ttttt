package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary NJS Public School Royal & Academic Blue Palette
val SchoolNavy = Color(0xFF123C73)
val SchoolAcademicBlue = Color(0xFF1E56A0)
val SchoolBrightAzure = Color(0xFF2B6CB0)
val SchoolSkyMist = Color(0xFFEAF2FC)
val SchoolIceSurface = Color(0xFFF6F9FE)
val SchoolPureWhite = Color(0xFFFFFFFF)
val SchoolBorderBlue = Color(0xFFD0E0F5)

// Heritage Torch Gold & Semantic Accents
val SchoolTorchGold = Color(0xFFD49B27)
val SchoolGoldSoft = Color(0xFFFFF6E0)
val SchoolGoldDarkText = Color(0xFF7A5300)

// Neutral & Text Ink Tokens
val SchoolInkDark = Color(0xFF0F172A)
val SchoolInkMuted = Color(0xFF475569)
val SchoolSuccessGreen = Color(0xFF15803D)
val SchoolSuccessSoft = Color(0xFFDCFCE7)
val SchoolAlertRed = Color(0xFFB91C1C)
val SchoolAlertSoft = Color(0xFFFEE2E2)

// Dark Mode Tokens
val SchoolDarkBg = Color(0xFF0A1424)
val SchoolDarkSurface = Color(0xFF112038)
val SchoolDarkSurfaceHigh = Color(0xFF1A2E4D)
val SchoolDarkBluePrimary = Color(0xFF8AB9F8)
val SchoolDarkOnPrimary = Color(0xFF092347)
val SchoolDarkOutline = Color(0xFF2E476B)
