package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.Notice
import com.example.data.model.SchoolContentCatalog
import com.example.data.preferences.WebsiteSyncMeta
import com.example.ui.components.CategoryPill
import com.example.ui.components.NoticeDetailDialog
import com.example.ui.components.SectionHeader
import com.example.ui.components.WebsiteSyncStatusBar
import com.example.ui.theme.SchoolGoldDarkText
import com.example.ui.theme.SchoolGoldSoft
import com.example.ui.theme.SchoolTorchGold
import com.example.ui.viewmodel.UiState

@Composable
fun NoticesScreen(
    noticesState: UiState<List<Notice>>,
    websiteSyncMeta: WebsiteSyncMeta,
    isSyncingWebsite: Boolean,
    onSyncWebsiteNow: () -> Unit,
    onToggleWebsiteAlerts: (Boolean) -> Unit,
    isAdmin: Boolean,
    isSubmitting: Boolean,
    selectedCategory: String,
    searchQuery: String,
    onCategorySelected: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSaveNotice: (
        editingId: String?,
        title: String,
        description: String,
        category: String,
        noticeDate: String,
        pinned: Boolean,
        status: String,
        imageUrl: String?,
        attachmentUrl: String?,
        attachmentLabel: String?,
        onDone: () -> Unit
    ) -> Unit,
    onDeleteNotice: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var detailNotice by remember { mutableStateOf<Notice?>(null) }
    var editorNotice by remember { mutableStateOf<Notice?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }
    var deleteCandidate by remember { mutableStateOf<Notice?>(null) }

    val categories = remember { listOf("All") + SchoolContentCatalog.noticeCategories }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            SectionHeader(
                title = "School Notices",
                subtitle = if (isAdmin) {
                    "Admin mode active: publish, edit, pin, or auto-sync website notices"
                } else {
                    "Auto-synced circulars, holidays, and website notifications"
                },
                icon = Icons.Default.Campaign
            )
            Spacer(modifier = Modifier.height(10.dp))
            WebsiteSyncStatusBar(
                syncMeta = websiteSyncMeta,
                isSyncing = isSyncingWebsite,
                onSyncNow = onSyncWebsiteNow,
                onToggleAlerts = onToggleWebsiteAlerts
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search notices or circulars...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("notice_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { onCategorySelected(category) },
                        label = { Text(category) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (noticesState) {
                is UiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = noticesState.message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                is UiState.Success -> {
                    val filtered = remember(noticesState.data, selectedCategory, searchQuery) {
                        noticesState.data.filter { notice ->
                            val matchesCat = selectedCategory == "All" ||
                                notice.category.equals(selectedCategory, ignoreCase = true)
                            val q = searchQuery.trim()
                            val matchesSearch = q.isEmpty() ||
                                notice.title.contains(q, ignoreCase = true) ||
                                notice.description.contains(q, ignoreCase = true) ||
                                notice.category.contains(q, ignoreCase = true)
                            matchesCat && matchesSearch
                        }
                    }

                    val publishedOrAllCount = noticesState.data.count { isAdmin || it.status == "published" }
                    if (publishedOrAllCount == 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            SchoolStatusBanner(isClosed = false)
                        }
                    } else if (filtered.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            SchoolStatusBanner(
                                isClosed = true,
                                noticeCount = publishedOrAllCount
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Campaign,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Text(
                                        text = "No matching notices found",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Try clearing your search or selecting All categories.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 88.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item(key = "school_status_banner") {
                                SchoolStatusBanner(
                                    isClosed = true,
                                    noticeCount = publishedOrAllCount
                                )
                            }
                            items(filtered, key = { it.id }) { notice ->
                                NoticeCard(
                                    notice = notice,
                                    isAdmin = isAdmin,
                                    onClick = { detailNotice = notice },
                                    onEdit = {
                                        editorNotice = notice
                                        showEditorDialog = true
                                    },
                                    onDelete = { deleteCandidate = notice }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isAdmin) {
            FloatingActionButton(
                onClick = {
                    editorNotice = null
                    showEditorDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(18.dp)
                    .testTag("add_notice_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Publish Notice")
            }
        }
    }

    detailNotice?.let { notice ->
        NoticeDetailDialog(
            notice = notice,
            isAdmin = isAdmin,
            onDismiss = { detailNotice = null },
            onEdit = {
                detailNotice = null
                editorNotice = notice
                showEditorDialog = true
            },
            onDelete = {
                detailNotice = null
                deleteCandidate = notice
            }
        )
    }

    if (showEditorDialog) {
        NoticeEditorDialog(
            existing = editorNotice,
            isSubmitting = isSubmitting,
            onDismiss = { showEditorDialog = false },
            onSave = { title, desc, cat, date, pinned, status, img, attUrl, attLabel ->
                onSaveNotice(
                    editorNotice?.id,
                    title,
                    desc,
                    cat,
                    date,
                    pinned,
                    status,
                    img,
                    attUrl,
                    attLabel
                ) {
                    showEditorDialog = false
                }
            }
        )
    }

    deleteCandidate?.let { candidate ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete Notice?") },
            text = { Text("Remove \"${candidate.title}\" permanently from the school notice board?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteNotice(candidate.id)
                        deleteCandidate = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun NoticeCard(
    notice: Notice,
    isAdmin: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val uriHandler = LocalUriHandler.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (notice.pinned) 1.5.dp else 1.dp,
            color = if (notice.pinned) SchoolTorchGold.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CategoryPill(label = notice.category)
                    if (notice.authorId == "website") {
                        CategoryPill(
                            label = "Website",
                            containerColor = SchoolGoldSoft,
                            contentColor = SchoolGoldDarkText
                        )
                    }
                    if (notice.pinned) {
                        CategoryPill(
                            label = "Pinned",
                            containerColor = SchoolGoldSoft,
                            contentColor = SchoolGoldDarkText
                        )
                    }
                    if (notice.status == "draft") {
                        CategoryPill(
                            label = "Draft",
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                Text(
                    text = notice.noticeDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (notice.pinned) {
                    Icon(
                        imageVector = Icons.Default.PushPin,
                        contentDescription = "Pinned",
                        tint = SchoolTorchGold,
                        modifier = Modifier
                            .size(16.dp)
                            .padding(end = 4.dp)
                    )
                }
                Text(
                    text = notice.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (!notice.imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = notice.imageUrl,
                    contentDescription = notice.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }

            Text(
                text = notice.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!notice.attachmentUrl.isNullOrBlank()) {
                    TextButton(
                        onClick = { uriHandler.openUri(notice.attachmentUrl) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(notice.attachmentLabel ?: "Attachment")
                    }
                } else {
                    Text(
                        text = notice.authorName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (isAdmin && !notice.localBaseline && notice.authorId != "website") {
                    Row {
                        IconButton(onClick = onEdit) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit notice",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onDelete) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete notice",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NoticeEditorDialog(
    existing: Notice?,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        description: String,
        category: String,
        noticeDate: String,
        pinned: Boolean,
        status: String,
        imageUrl: String?,
        attachmentUrl: String?,
        attachmentLabel: String?
    ) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "Circular") }
    var noticeDate by remember { mutableStateOf(existing?.noticeDate ?: "2026-11-16") }
    var pinned by remember { mutableStateOf(existing?.pinned ?: false) }
    var published by remember { mutableStateOf((existing?.status ?: "published") == "published") }
    var imageUrl by remember { mutableStateOf(existing?.imageUrl ?: "") }
    var attachmentUrl by remember { mutableStateOf(existing?.attachmentUrl ?: "") }
    var attachmentLabel by remember { mutableStateOf(existing?.attachmentLabel ?: "") }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (existing == null) "Publish School Notice" else "Edit School Notice")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notice Title*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = noticeDate,
                    onValueChange = { noticeDate = it },
                    label = { Text("Date (e.g. 2026-11-16)*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Category",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(SchoolContentCatalog.noticeCategories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description*") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    label = { Text("Image URL (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = attachmentUrl,
                    onValueChange = { attachmentUrl = it },
                    label = { Text("Attachment Link URL (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = attachmentLabel,
                    onValueChange = { attachmentLabel = it },
                    label = { Text("Attachment Button Label (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pin as Important Announcement", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = pinned, onCheckedChange = { pinned = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Publish Immediately", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = published, onCheckedChange = { published = it })
                }
                if (!validationError.isNullOrBlank()) {
                    Text(
                        text = validationError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val t = title.trim()
                    val d = description.trim()
                    val dt = noticeDate.trim()
                    when {
                        t.length !in 3..140 -> validationError = "Title must be 3 to 140 characters."
                        d.length !in 5..2000 -> validationError = "Description must be 5 to 2000 characters."
                        dt.length !in 4..40 -> validationError = "Date must be 4 to 40 characters."
                        else -> {
                            validationError = null
                            onSave(
                                t,
                                d,
                                category,
                                dt,
                                pinned,
                                if (published) "published" else "draft",
                                imageUrl.trim().takeIf { it.isNotEmpty() },
                                attachmentUrl.trim().takeIf { it.isNotEmpty() },
                                attachmentLabel.trim().takeIf { it.isNotEmpty() }
                            )
                        }
                    }
                },
                enabled = !isSubmitting
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(if (existing == null) "Publish" else "Save")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
