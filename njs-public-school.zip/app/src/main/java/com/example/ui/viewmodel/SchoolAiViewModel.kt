package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Notice
import com.example.data.model.SchoolContentCatalog
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.UUID

data class AiChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false,
    val isError: Boolean = false
)

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Streaming(val text: String) : AiUiState
    data class Success(val text: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

class SchoolAiViewModel : ViewModel() {

    private val systemPrompt = buildString {
        appendLine("You are the fast AI School Assistant for NJS Public School (\"Creator of Knowledge\").")
        appendLine("Address: ${SchoolContentCatalog.SCHOOL_ADDRESS} | Contact Phone: ${SchoolContentCatalog.CONTACT_PHONE}")
        appendLine("Portal: ${SchoolContentCatalog.PORTAL_URL} | YouTube: ${SchoolContentCatalog.YOUTUBE_URL}")
        appendLine("Facilities: 400m Olympic running track & basketball courts, Cricket Academy & turf pitch, Floodlit football turf, Terracotta & clay sculpting studio, Havan & moral mentoring.")
        appendLine("Events: Hastinapur educational excursions, Eco-friendly Diwali/Rangoli/Rakhi, Earth Day projects, Annual Gala & Convocation.")
        appendLine("Rules: Reply quickly, concisely (2-4 short sentences unless asked for detail), in the user's language (English or Hindi). Use the provided LIVE STATUS to answer if school is open/closed. Never invent unverified fees or extra numbers.")
    }

    private val fastConfig = generationConfig {
        temperature = 0.4f
        maxOutputTokens = 450
    }

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = fastConfig,
            systemInstruction = content { text(systemPrompt) }
        )
    }

    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    private val _messages = MutableStateFlow<List<AiChatMessage>>(emptyList())
    val messages: StateFlow<List<AiChatMessage>> = _messages.asStateFlow()

    fun askQuestion(
        question: String,
        visitorName: String,
        activeNotices: List<Notice>
    ) {
        val cleanQuestion = question.trim()
        if (cleanQuestion.isEmpty()) return
        if (_uiState.value is AiUiState.Loading || _uiState.value is AiUiState.Streaming) return

        val userMsg = AiChatMessage(isUser = true, text = cleanQuestion)
        val assistantMsgId = UUID.randomUUID().toString()
        val placeholderReply = AiChatMessage(
            id = assistantMsgId,
            isUser = false,
            text = "",
            isStreaming = true
        )

        val priorHistory = _messages.value.takeLast(4).filter { !it.isError && it.text.isNotBlank() }
        _messages.value = _messages.value + userMsg + placeholderReply

        val prompt = buildContextualPrompt(
            question = cleanQuestion,
            visitorName = visitorName,
            activeNotices = activeNotices,
            history = priorHistory
        )

        viewModelScope.launch {
            _uiState.value = AiUiState.Loading
            val accumulatedText = StringBuilder()
            try {
                withTimeout(45_000L) {
                    model.generateContentStream(prompt).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        if (chunkText.isNotEmpty()) {
                            accumulatedText.append(chunkText)
                            val partial = accumulatedText.toString()
                            _uiState.value = AiUiState.Streaming(partial)
                            updateAssistantMessage(
                                messageId = assistantMsgId,
                                text = partial,
                                isStreaming = true,
                                isError = false
                            )
                        }
                    }
                }
                val finalText = accumulatedText.toString().trim()
                if (finalText.isNotEmpty()) {
                    _uiState.value = AiUiState.Success(finalText)
                    updateAssistantMessage(
                        messageId = assistantMsgId,
                        text = finalText,
                        isStreaming = false,
                        isError = false
                    )
                } else {
                    val emptyErr = "The assistant returned an empty response. Please try again."
                    _uiState.value = AiUiState.Error(emptyErr)
                    updateAssistantMessage(
                        messageId = assistantMsgId,
                        text = emptyErr,
                        isStreaming = false,
                        isError = true
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI Assistant request timed out", e)
                val msg = "Request timed out. Please check your connection and try again."
                _uiState.value = AiUiState.Error(msg)
                updateAssistantMessage(
                    messageId = assistantMsgId,
                    text = msg,
                    isStreaming = false,
                    isError = true
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI Assistant failed", e)
                val msg = e.localizedMessage ?: "Unable to connect to the School AI Assistant right now."
                _uiState.value = AiUiState.Error(msg)
                updateAssistantMessage(
                    messageId = assistantMsgId,
                    text = msg,
                    isStreaming = false,
                    isError = true
                )
            }
        }
    }

    fun clearConversation() {
        _messages.value = emptyList()
        _uiState.value = AiUiState.Idle
    }

    private fun updateAssistantMessage(
        messageId: String,
        text: String,
        isStreaming: Boolean,
        isError: Boolean
    ) {
        _messages.value = _messages.value.map { msg ->
            if (msg.id == messageId) {
                msg.copy(text = text, isStreaming = isStreaming, isError = isError)
            } else {
                msg
            }
        }
    }

    private fun buildContextualPrompt(
        question: String,
        visitorName: String,
        activeNotices: List<Notice>,
        history: List<AiChatMessage>
    ): String {
        return buildString {
            if (activeNotices.isEmpty()) {
                appendLine("LIVE STATUS: SCHOOL IS OPEN (स्कूल खुला है). 0 active notices.")
            } else {
                appendLine("LIVE STATUS: SCHOOL IS CLOSE (${activeNotices.size} active notices):")
                activeNotices.take(5).forEachIndexed { idx, notice ->
                    appendLine("${idx + 1}. [${notice.category}] ${notice.title} (${notice.noticeDate}): ${notice.description.take(240)}")
                }
            }
            if (visitorName.isNotBlank()) {
                appendLine("Visitor: $visitorName")
            }
            if (history.isNotEmpty()) {
                history.forEach { item ->
                    appendLine("${if (item.isUser) "U" else "A"}: ${item.text.take(220)}")
                }
            }
            appendLine("Q: $question")
        }
    }

    private companion object {
        const val TAG = "SchoolAiViewModel"
    }
}
