package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Notice
import com.example.ui.components.CategoryPill
import com.example.ui.components.SchoolCrestBadge
import com.example.ui.theme.SchoolAcademicBlue
import com.example.ui.theme.SchoolAlertRed
import com.example.ui.theme.SchoolAlertSoft
import com.example.ui.theme.SchoolGoldDarkText
import com.example.ui.theme.SchoolGoldSoft
import com.example.ui.theme.SchoolNavy
import com.example.ui.theme.SchoolPureWhite
import com.example.ui.theme.SchoolSuccessGreen
import com.example.ui.theme.SchoolSuccessSoft
import com.example.ui.theme.SchoolTorchGold
import com.example.ui.viewmodel.AiChatMessage
import com.example.ui.viewmodel.AiUiState
import com.example.ui.viewmodel.SchoolAiViewModel

private data class AiSearchTopic(
    val title: String,
    val subtitle: String,
    val prompt: String,
    val keywords: String,
    val icon: ImageVector
)

@Composable
fun AiAssistantScreen(
    aiViewModel: SchoolAiViewModel,
    visitorName: String,
    activeNotices: List<Notice>,
    modifier: Modifier = Modifier
) {
    val messages by aiViewModel.messages.collectAsStateWithLifecycle()
    val uiState by aiViewModel.uiState.collectAsStateWithLifecycle()
    var inputText by rememberSaveable { mutableStateOf("") }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val keyboardController = LocalSoftwareKeyboardController.current

    val isBusy = uiState is AiUiState.Loading || uiState is AiUiState.Streaming

    val quickPrompts = remember {
        listOf(
            "Is school open today?",
            "कल स्कूल खुला है या छुट्टी है?",
            "Any new notices?",
            "Sports & campus facilities",
            "Hastinapur excursion details",
            "How to apply for admission?"
        )
    }

    val searchableTopics = remember {
        listOf(
            AiSearchTopic(
                title = "Live School Open / Holiday Status",
                subtitle = "Check if school is open today or any holiday notice is active",
                prompt = "Is school open today? Please check active notices.",
                keywords = "open close holiday status today chutti school",
                icon = Icons.Default.CheckCircle
            ),
            AiSearchTopic(
                title = "School Notices & Circulars",
                subtitle = "Summarize active announcements synced from njspublicschool.pages.dev",
                prompt = "Summarize all active school notices and announcements.",
                keywords = "notice circular announcement update website",
                icon = Icons.Default.Campaign
            ),
            AiSearchTopic(
                title = "Sports & Fine Arts Facilities",
                subtitle = "400m Olympic track, Cricket Academy, Football turf, Clay studio",
                prompt = "Tell me about sports and fine arts facilities at NJS Public School.",
                keywords = "sports track cricket football clay terracotta havan facility",
                icon = Icons.AutoMirrored.Filled.DirectionsRun
            ),
            AiSearchTopic(
                title = "Events & Hastinapur Excursion",
                subtitle = "Educational field trips, Diwali/Rangoli, Earth Day & Annual Gala",
                prompt = "Tell me about events, celebrations, and Hastinapur excursions.",
                keywords = "event hastinapur excursion trip diwali rangoli gala",
                icon = Icons.Default.Celebration
            ),
            AiSearchTopic(
                title = "Admissions & Academic Mentorship",
                subtitle = "Admission inquiry process, faculty mentorship & digital portal",
                prompt = "How can parents submit an admission inquiry and what is the academic approach?",
                keywords = "admission apply inquiry form fees academic mentorship portal",
                icon = Icons.Default.School
            ),
            AiSearchTopic(
                title = "Contact Number & Campus Address",
                subtitle = "Behjadka, Niloha, Mawana, Meerut • 9548576481",
                prompt = "What is the school contact number and campus address?",
                keywords = "contact phone number 9548576481 address location behjadka niloha mawana meerut",
                icon = Icons.Default.LocationOn
            ),
            AiSearchTopic(
                title = "Hindi / Bilingual School Help",
                subtitle = "स्कूल की जानकारी, छुट्टी और नोटिस हिंदी में पूछें",
                prompt = "एनजेएस पब्लिक स्कूल और आज की स्कूल स्थिति के बारे में हिंदी में बताएं।",
                keywords = "hindi हिंदी chhutti school status",
                icon = Icons.AutoMirrored.Filled.MenuBook
            )
        )
    }

    val trimmedSearch = searchQuery.trim()
    val filteredPrompts = remember(trimmedSearch, quickPrompts) {
        if (trimmedSearch.isBlank()) {
            quickPrompts
        } else {
            quickPrompts.filter { it.contains(trimmedSearch, ignoreCase = true) }
        }
    }

    val filteredTopics = remember(trimmedSearch, searchableTopics) {
        if (trimmedSearch.isBlank()) {
            searchableTopics
        } else {
            searchableTopics.filter {
                it.title.contains(trimmedSearch, ignoreCase = true) ||
                    it.subtitle.contains(trimmedSearch, ignoreCase = true) ||
                    it.keywords.contains(trimmedSearch, ignoreCase = true) ||
                    it.prompt.contains(trimmedSearch, ignoreCase = true)
            }
        }
    }

    val visibleMessages = remember(messages, trimmedSearch) {
        if (trimmedSearch.isBlank()) {
            messages
        } else {
            messages.filter { it.text.contains(trimmedSearch, ignoreCase = true) }
        }
    }

    fun submitQuery(query: String, clearSearchAfter: Boolean = false) {
        val clean = query.trim()
        if (clean.isEmpty() || isBusy) return
        keyboardController?.hide()
        if (clearSearchAfter) {
            searchQuery = ""
        }
        aiViewModel.askQuestion(clean, visitorName, activeNotices)
    }

    LaunchedEffect(visibleMessages.size, visibleMessages.lastOrNull()?.text) {
        if (visibleMessages.isNotEmpty() && trimmedSearch.isBlank()) {
            listState.animateScrollToItem(visibleMessages.lastIndex)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Clean Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SchoolCrestBadge(size = 44.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "NJS AI Assistant",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        CategoryPill(
                            label = "Fast AI",
                            containerColor = SchoolGoldSoft,
                            contentColor = SchoolGoldDarkText
                        )
                    }
                    Text(
                        text = "Search school topics or ask in English & हिन्दी",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (messages.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            searchQuery = ""
                            aiViewModel.clearConversation()
                        },
                        modifier = Modifier.testTag("ai_clear_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Clear AI conversation"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Live notice status pill matching website & dashboard
            val isClosed = activeNotices.isNotEmpty()
            val statusAccent = if (isClosed) SchoolAlertRed else SchoolSuccessGreen
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (isClosed) SchoolAlertSoft else SchoolSuccessSoft,
                border = BorderStroke(1.dp, statusAccent.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(statusAccent)
                    )
                    Text(
                        text = if (isClosed) {
                            "LIVE STATUS: SCHOOL IS CLOSE (${activeNotices.size} notice active)"
                        } else {
                            "LIVE STATUS: SCHOOL IS OPEN (No active notices)"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = statusAccent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dedicated AI Search Bar: filters topics/chat history & launches 1-tap AI Search
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        text = "Search AI topics, answers, or ask...",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search AI",
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier.testTag("ai_search_clear")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear AI search"
                            )
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = { submitQuery(trimmedSearch, clearSearchAfter = true) }
                ),
                shape = RoundedCornerShape(50),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_search_input")
            )

            // Instant "Search & Ask AI" action bar when typing in the search bar
            if (trimmedSearch.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !isBusy) {
                            submitQuery(trimmedSearch, clearSearchAfter = true)
                        }
                        .testTag("ai_search_ask_button")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Ask NJS AI: \"$trimmedSearch\"",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (messages.isNotEmpty()) {
                                Text(
                                    text = "${visibleMessages.size} matching message(s) in chat • Tap to ask AI",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Ask AI",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (filteredPrompts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filteredPrompts) { prompt ->
                        AssistChip(
                            onClick = { submitQuery(prompt, clearSearchAfter = true) },
                            enabled = !isBusy,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            label = { Text(prompt) },
                            shape = RoundedCornerShape(50),
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Main Conversation & Searchable Topics Area
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (messages.isEmpty()) {
                    if (trimmedSearch.isBlank()) {
                        item {
                            AiWelcomeHeroCard(visitorName = visitorName)
                        }
                    }

                    if (filteredTopics.isNotEmpty()) {
                        item {
                            Text(
                                text = if (trimmedSearch.isBlank()) {
                                    "Explore Topics with AI"
                                } else {
                                    "Matching School AI Topics (${filteredTopics.size})"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        items(filteredTopics, key = { it.title }) { topic ->
                            AiTopicCard(
                                topic = topic,
                                enabled = !isBusy,
                                onClick = { submitQuery(topic.prompt, clearSearchAfter = true) }
                            )
                        }
                    }
                } else if (visibleMessages.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = "No past messages match \"$trimmedSearch\"",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tap below to search NJS AI directly for this question.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { searchQuery = "" }) {
                                        Text("Show All Chat")
                                    }
                                    Button(
                                        onClick = { submitQuery(trimmedSearch, clearSearchAfter = true) },
                                        enabled = !isBusy
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Ask AI Now")
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(visibleMessages, key = { it.id }) { msg ->
                        ChatBubble(message = msg)
                    }
                }
            }

            // Bottom Composer Bar
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                tonalElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = "Ask AI about holidays, notices, school...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        singleLine = false,
                        maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (inputText.isNotBlank() && !isBusy) {
                                    val q = inputText
                                    inputText = ""
                                    submitQuery(q)
                                }
                            }
                        ),
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_question_input")
                    )

                    FilledIconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !isBusy) {
                                val q = inputText
                                inputText = ""
                                submitQuery(q)
                            }
                        },
                        enabled = inputText.isNotBlank() && !isBusy,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("ai_send_button")
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send question to AI Assistant"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AiWelcomeHeroCard(visitorName: String) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = SchoolNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(SchoolNavy, SchoolAcademicBlue)
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SchoolCrestBadge(size = 46.dp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Namaste, ${visitorName.ifBlank { "Student" }}!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SchoolPureWhite
                        )
                        Text(
                            text = "NJS Public School Smart Assistant",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFFFE199)
                        )
                    }
                }
                Text(
                    text = "Use the search bar above or tap any topic below to check today's school status, circulars, facilities, Hastinapur excursions, or admissions in English or Hindi.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SchoolPureWhite.copy(alpha = 0.9f)
                )
            }
        }
    }
}

@Composable
private fun AiTopicCard(
    topic: AiSearchTopic,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Icon(
                    imageVector = topic.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(9.dp)
                        .size(20.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = topic.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = topic.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Ask AI about ${topic.title}",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ChatBubble(message: AiChatMessage) {
    if (message.isUser) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 4.dp, bottomStart = 20.dp, bottomEnd = 20.dp),
                color = SchoolNavy,
                tonalElevation = 1.dp,
                modifier = Modifier.widthIn(max = 520.dp)
            ) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SchoolPureWhite,
                    modifier = Modifier.padding(horizontal = 15.dp, vertical = 11.dp)
                )
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.Top
        ) {
            SchoolCrestBadge(size = 34.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Card(
                shape = RoundedCornerShape(topStart = 4.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (message.isError) {
                        MaterialTheme.colorScheme.errorContainer
                    } else {
                        MaterialTheme.colorScheme.surface
                    }
                ),
                border = BorderStroke(
                    1.dp,
                    if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.widthIn(max = 560.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (message.isError) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Assistant Error",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = SchoolTorchGold,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "NJS AI",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (message.text.isBlank() && message.isStreaming) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Text(
                                text = "Thinking...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (message.isError) {
                                MaterialTheme.colorScheme.onErrorContainer
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        }
    }
}
