package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.Notice

object WebsiteNotificationHelper {

    const val CHANNEL_ID = "njs_website_notices"
    const val EXTRA_OPEN_NOTICES = "extra_open_notices"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "School Website Notices",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Automatic alerts when new notices are published on njspublicschool.pages.dev"
                    enableVibration(true)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun canPostNotifications(context: Context): Boolean {
        return hasNotificationPermission(context) &&
            NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun showNewNoticesNotification(context: Context, newNotices: List<Notice>) {
        if (newNotices.isEmpty()) return
        ensureChannel(context)
        if (!canPostNotifications(context)) return

        val appContext = context.applicationContext
        val intent = Intent(appContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_NOTICES, true)
        }
        val pendingIntent = PendingIntent.getActivity(
            appContext,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val largeIcon = runCatching {
            BitmapFactory.decodeResource(appContext.resources, R.drawable.img_school_crest)
        }.getOrNull()

        val manager = NotificationManagerCompat.from(appContext)
        newNotices.take(3).forEachIndexed { index, notice ->
            val notification = NotificationCompat.Builder(appContext, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .apply { if (largeIcon != null) setLargeIcon(largeIcon) }
                .setContentTitle("NJS School • ${notice.category}")
                .setContentText(notice.title)
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .setBigContentTitle(notice.title)
                        .bigText(notice.description)
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            val notifId = (notice.id.hashCode() and 0x7FFFFFFF).let { if (it == 0) 2000 + index else it }
            try {
                manager.notify(notifId, notification)
            } catch (_: SecurityException) {
                // Permission was revoked concurrently
            }
        }
    }
}
