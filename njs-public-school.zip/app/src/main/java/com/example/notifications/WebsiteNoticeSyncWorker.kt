package com.example.notifications

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.preferences.ThemePreferencesRepository
import com.example.data.remote.WebsiteNoticeSyncEngine
import java.util.concurrent.TimeUnit

class WebsiteNoticeSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val prefs = ThemePreferencesRepository(applicationContext)
        val syncEngine = WebsiteNoticeSyncEngine(context = applicationContext)
        val syncResult = syncEngine.syncFromWebsite(allowWebViewFallback = false)

        if (!syncResult.success) {
            return if (runAttemptCount < 2) Result.retry() else Result.success()
        }

        val newlyDiscovered = prefs.saveWebsiteSyncResult(
            notices = syncResult.notices,
            success = true
        )

        if (newlyDiscovered.isNotEmpty() && prefs.areWebsiteAlertsEnabled()) {
            WebsiteNotificationHelper.showNewNoticesNotification(
                context = applicationContext,
                newNotices = newlyDiscovered
            )
        }
        return Result.success()
    }

    companion object {
        private const val PERIODIC_WORK_NAME = "njs_website_notice_periodic_sync"
        private const val IMMEDIATE_WORK_NAME = "njs_website_notice_immediate_sync"

        fun schedulePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<WebsiteNoticeSyncWorker>(
                15,
                TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context.applicationContext)
                .enqueueUniquePeriodicWork(
                    PERIODIC_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
        }

        fun triggerImmediateSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<WebsiteNoticeSyncWorker>()
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context.applicationContext)
                .enqueueUniqueWork(
                    IMMEDIATE_WORK_NAME,
                    ExistingWorkPolicy.REPLACE,
                    request
                )
        }
    }
}
