package com.example

import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.ai.configureAppCheck
import com.example.data.preferences.ThemePreferencesRepository
import com.example.data.remote.SchoolRepository
import com.example.data.remote.authStateFlow
import com.example.notifications.WebsiteNoticeSyncWorker
import com.example.notifications.WebsiteNotificationHelper
import com.example.ui.navigation.NjsAppShell
import com.example.ui.screens.WelcomeNameScreen
import com.example.ui.theme.NjsSchoolTheme
import com.example.ui.viewmodel.SchoolViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var openNoticesSignal by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                AndroidColor.TRANSPARENT,
                AndroidColor.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.light(
                AndroidColor.TRANSPARENT,
                AndroidColor.TRANSPARENT
            )
        )

        WebsiteNotificationHelper.ensureChannel(applicationContext)
        WebsiteNoticeSyncWorker.schedulePeriodicSync(applicationContext)
        openNoticesSignal = intent?.getBooleanExtra(WebsiteNotificationHelper.EXTRA_OPEN_NOTICES, false) == true

        val preferencesRepo = ThemePreferencesRepository(applicationContext)

        setContent {
            val isDarkMode = false

            NjsSchoolTheme(darkTheme = false) {
                AppNavigation(
                    preferencesRepo = preferencesRepo,
                    isDarkMode = isDarkMode,
                    openNoticesOnStart = openNoticesSignal,
                    onConsumedOpenNotices = { openNoticesSignal = false },
                    onToggleDarkMode = {}
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(WebsiteNotificationHelper.EXTRA_OPEN_NOTICES, false)) {
            openNoticesSignal = true
        }
    }
}

@Composable
fun AppNavigation(
    preferencesRepo: ThemePreferencesRepository,
    isDarkMode: Boolean,
    openNoticesOnStart: Boolean = false,
    onConsumedOpenNotices: () -> Unit = {},
    onToggleDarkMode: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val activeVisitorName by preferencesRepo.activeVisitorName.collectAsStateWithLifecycle(initialValue = "")
    val capturedVisitors by preferencesRepo.capturedVisitors.collectAsStateWithLifecycle(initialValue = emptyList())

    val auth = remember { Firebase.auth }
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

    if (activeVisitorName.isBlank()) {
        WelcomeNameScreen(
            recentVisitors = capturedVisitors,
            onStartWithName = { enteredName ->
                scope.launch {
                    preferencesRepo.captureVisitorName(enteredName)
                }
            },
            onSelectRecentName = { selectedName ->
                scope.launch {
                    preferencesRepo.captureVisitorName(selectedName)
                }
            }
        )
    } else {
        val sessionKey = currentUser?.uid ?: "guest_visitor"
        key(sessionKey) {
            val viewModel: SchoolViewModel = viewModel(
                key = sessionKey,
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY]) {
                            "APPLICATION_KEY missing from CreationExtras"
                        }
                        val databaseId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(databaseId)
                        SchoolViewModel(
                            appContext = app.applicationContext,
                            repository = SchoolRepository(db),
                            preferences = preferencesRepo,
                            currentUserId = currentUser?.uid
                        )
                    }
                }
            )
            NjsAppShell(
                viewModel = viewModel,
                activeVisitorName = activeVisitorName,
                capturedVisitors = capturedVisitors,
                isCloudSignedIn = currentUser != null,
                cloudUserEmail = currentUser?.email ?: "",
                isDarkMode = isDarkMode,
                openNoticesOnStart = openNoticesOnStart,
                onConsumedOpenNotices = onConsumedOpenNotices,
                onToggleDarkMode = onToggleDarkMode,
                onSwitchVisitorName = {
                    scope.launch {
                        preferencesRepo.clearActiveVisitor()
                    }
                },
                onSelectVisitorName = { name ->
                    scope.launch {
                        preferencesRepo.selectExistingVisitor(name)
                    }
                },
                onClearCapturedVisitors = {
                    scope.launch {
                        preferencesRepo.clearCapturedVisitors()
                    }
                }
            )
        }
    }
}
