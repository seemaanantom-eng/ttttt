package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.Notice
import com.example.data.model.SchoolContentCatalog
import com.example.data.model.SchoolInquiry
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class SchoolRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    suspend fun checkAdminPrivilege(uid: String): Boolean {
        val currentUser = auth.currentUser ?: return false
        if (currentUser.isEmailVerified &&
            currentUser.email.equals(SchoolContentCatalog.ADMIN_EMAIL, ignoreCase = true)
        ) {
            return true
        }
        return try {
            val snap = db.collection("admins").document(uid).get().await()
            snap.exists()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    fun observeNotices(isAdmin: Boolean): Flow<List<Notice>> = flow {
        val uid = requireUserId()
        val path = "notices"
        val query = if (isAdmin) {
            db.collection(path)
        } else {
            db.collection(path).whereEqualTo("status", "published")
        }
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Notice::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun publishNotice(
        title: String,
        description: String,
        category: String,
        noticeDate: String,
        pinned: Boolean,
        status: String,
        imageUrl: String?,
        attachmentUrl: String?,
        attachmentLabel: String?
    ): Result<Unit> {
        var docPath = "notices"
        return try {
            val uid = requireUserId()
            val cleanTitle = title.trim()
            val cleanDesc = description.trim()
            val cleanDate = noticeDate.trim()
            val cleanCategory = category.trim()
            val cleanStatus = status.trim()

            require(cleanTitle.length in 3..140) { "Notice title must be 3 to 140 characters." }
            require(cleanDesc.length in 5..2000) { "Notice description must be 5 to 2000 characters." }
            require(cleanDate.length in 4..40) { "Notice date must be 4 to 40 characters." }
            require(cleanCategory in SchoolContentCatalog.noticeCategories) { "Invalid notice category." }
            require(cleanStatus == "published" || cleanStatus == "draft") { "Invalid notice status." }

            val cleanImageUrl = imageUrl?.trim()?.takeIf { it.isNotEmpty() }
            val cleanAttachmentUrl = attachmentUrl?.trim()?.takeIf { it.isNotEmpty() }
            val cleanAttachmentLabel = attachmentLabel?.trim()?.takeIf { it.isNotEmpty() }

            if (cleanImageUrl != null) require(cleanImageUrl.length <= 500) { "Image URL is too long." }
            if (cleanAttachmentUrl != null) require(cleanAttachmentUrl.length <= 500) { "Attachment URL is too long." }
            if (cleanAttachmentLabel != null) require(cleanAttachmentLabel.length <= 120) { "Attachment label is too long." }

            val docRef = db.collection("notices").document()
            docPath = docRef.path
            val authorName = (auth.currentUser?.displayName?.trim()?.takeIf { it.isNotEmpty() }
                ?: "NJS School Admin").take(100)

            val payload = mapOf(
                "authorId" to uid,
                "authorName" to authorName,
                "title" to cleanTitle,
                "description" to cleanDesc,
                "category" to cleanCategory,
                "noticeDate" to cleanDate,
                "pinned" to pinned,
                "status" to cleanStatus,
                "imageUrl" to cleanImageUrl,
                "attachmentUrl" to cleanAttachmentUrl,
                "attachmentLabel" to cleanAttachmentLabel,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateNotice(
        noticeId: String,
        title: String,
        description: String,
        category: String,
        noticeDate: String,
        pinned: Boolean,
        status: String,
        imageUrl: String?,
        attachmentUrl: String?,
        attachmentLabel: String?
    ): Result<Unit> {
        var docPath = "notices/$noticeId"
        return try {
            requireUserId()
            require(noticeId.isNotBlank()) { "Notice ID cannot be blank." }
            val cleanTitle = title.trim()
            val cleanDesc = description.trim()
            val cleanDate = noticeDate.trim()
            val cleanCategory = category.trim()
            val cleanStatus = status.trim()

            require(cleanTitle.length in 3..140) { "Notice title must be 3 to 140 characters." }
            require(cleanDesc.length in 5..2000) { "Notice description must be 5 to 2000 characters." }
            require(cleanDate.length in 4..40) { "Notice date must be 4 to 40 characters." }
            require(cleanCategory in SchoolContentCatalog.noticeCategories) { "Invalid notice category." }
            require(cleanStatus == "published" || cleanStatus == "draft") { "Invalid notice status." }

            val cleanImageUrl = imageUrl?.trim()?.takeIf { it.isNotEmpty() }
            val cleanAttachmentUrl = attachmentUrl?.trim()?.takeIf { it.isNotEmpty() }
            val cleanAttachmentLabel = attachmentLabel?.trim()?.takeIf { it.isNotEmpty() }

            if (cleanImageUrl != null) require(cleanImageUrl.length <= 500) { "Image URL is too long." }
            if (cleanAttachmentUrl != null) require(cleanAttachmentUrl.length <= 500) { "Attachment URL is too long." }
            if (cleanAttachmentLabel != null) require(cleanAttachmentLabel.length <= 120) { "Attachment label is too long." }

            val docRef = db.collection("notices").document(noticeId)
            docPath = docRef.path
            val updates = mapOf<String, Any>(
                "title" to cleanTitle,
                "description" to cleanDesc,
                "category" to cleanCategory,
                "noticeDate" to cleanDate,
                "pinned" to pinned,
                "status" to cleanStatus,
                "imageUrl" to (cleanImageUrl ?: FieldValue.delete()),
                "attachmentUrl" to (cleanAttachmentUrl ?: FieldValue.delete()),
                "attachmentLabel" to (cleanAttachmentLabel ?: FieldValue.delete()),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteNotice(noticeId: String): Result<Unit> {
        var docPath = "notices/$noticeId"
        return try {
            requireUserId()
            require(noticeId.isNotBlank()) { "Notice ID cannot be blank." }
            val docRef = db.collection("notices").document(noticeId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    fun observeInquiries(userId: String, isAdmin: Boolean): Flow<List<SchoolInquiry>> = flow {
        val uid = requireUserId()
        val path = "inquiries"
        val query = if (isAdmin) {
            db.collection(path)
        } else {
            db.collection(path).whereEqualTo("userId", userId)
        }
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        SchoolInquiry::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun submitInquiry(
        inquiryType: String,
        senderName: String,
        senderEmail: String,
        contactPhone: String,
        studentName: String?,
        gradeLevel: String?,
        subject: String,
        message: String
    ): Result<Unit> {
        var docPath = "inquiries"
        return try {
            val uid = requireUserId()
            val cleanType = inquiryType.trim()
            val cleanName = senderName.trim()
            val cleanEmail = senderEmail.trim()
            val cleanPhone = contactPhone.trim()
            val cleanSubject = subject.trim()
            val cleanMessage = message.trim()
            val cleanStudent = studentName?.trim()?.takeIf { it.isNotEmpty() }
            val cleanGrade = gradeLevel?.trim()?.takeIf { it.isNotEmpty() }

            require(cleanType == "admission" || cleanType == "contact") { "Invalid inquiry type." }
            require(cleanName.length in 2..100) { "Full name must be 2 to 100 characters." }
            require(cleanEmail.length in 3..150) { "Email address must be 3 to 150 characters." }
            require(cleanPhone.length in 5..30) { "Contact phone must be 5 to 30 characters." }
            require(cleanSubject.length in 3..140) { "Subject must be 3 to 140 characters." }
            require(cleanMessage.length in 5..2000) { "Message must be 5 to 2000 characters." }
            if (cleanStudent != null) require(cleanStudent.length <= 100) { "Student name is too long." }
            if (cleanGrade != null) require(cleanGrade.length <= 60) { "Class/grade level is too long." }

            val docRef = db.collection("inquiries").document()
            docPath = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "inquiryType" to cleanType,
                "senderName" to cleanName,
                "senderEmail" to cleanEmail,
                "contactPhone" to cleanPhone,
                "studentName" to cleanStudent,
                "gradeLevel" to cleanGrade,
                "subject" to cleanSubject,
                "message" to cleanMessage,
                "status" to "submitted",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateInquiryReviewByAdmin(
        inquiryId: String,
        status: String,
        adminReply: String?
    ): Result<Unit> {
        var docPath = "inquiries/$inquiryId"
        return try {
            requireUserId()
            require(inquiryId.isNotBlank()) { "Inquiry ID cannot be blank." }
            require(status in SchoolContentCatalog.inquiryStatuses) { "Invalid status." }
            val cleanReply = adminReply?.trim()?.takeIf { it.isNotEmpty() }
            if (cleanReply != null) require(cleanReply.length <= 1000) { "Reply is too long." }

            val docRef = db.collection("inquiries").document(inquiryId)
            docPath = docRef.path
            val updates = mapOf<String, Any>(
                "status" to status,
                "adminReply" to (cleanReply ?: FieldValue.delete()),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteInquiry(inquiryId: String): Result<Unit> {
        var docPath = "inquiries/$inquiryId"
        return try {
            requireUserId()
            require(inquiryId.isNotBlank()) { "Inquiry ID cannot be blank." }
            val docRef = db.collection("inquiries").document(inquiryId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }
}
