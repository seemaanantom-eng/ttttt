package com.example.data.model

import androidx.annotation.DrawableRes
import androidx.annotation.Keep
import com.example.R
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class Notice(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "Circular",
    val noticeDate: String = "",
    val pinned: Boolean = false,
    val status: String = "published",
    val imageUrl: String? = null,
    val attachmentUrl: String? = null,
    val attachmentLabel: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
    val localBaseline: Boolean = false
)

@Keep
@IgnoreExtraProperties
data class SchoolInquiry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val inquiryType: String = "contact",
    val senderName: String = "",
    val senderEmail: String = "",
    val contactPhone: String = "",
    val studentName: String? = null,
    val gradeLevel: String? = null,
    val subject: String = "",
    val message: String = "",
    val status: String = "submitted",
    val adminReply: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class FacilityItem(
    val title: String,
    val subtitle: String,
    val description: String,
    val highlights: List<String>,
    @DrawableRes val imageRes: Int? = null
)

data class EventItem(
    val title: String,
    val category: String,
    val summary: String,
    val highlights: List<String>,
    @DrawableRes val imageRes: Int? = null
)

data class GalleryPhoto(
    val id: String,
    val title: String,
    val category: String,
    val caption: String,
    @DrawableRes val imageRes: Int
)

data class AcademicProgram(
    val title: String,
    val badge: String,
    val description: String
)

object SchoolContentCatalog {
    const val SCHOOL_NAME = "NJS Public School"
    const val SCHOOL_SHORT_NAME = "NJS School"
    const val MOTTO = "Creator of Knowledge"
    const val PORTAL_URL = "https://njspublicschool.pages.dev"
    const val YOUTUBE_URL = "https://www.youtube.com/@anantgahlaut"
    const val YOUTUBE_HANDLE = "@anantgahlaut"
    const val CONTACT_PHONE = "9548576481"
    const val CONTACT_PHONE_URL = "tel:9548576481"
    const val SCHOOL_ADDRESS = "Behjadka, Niloha, Mawana, Meerut"
    const val SCHOOL_MAP_URL = "https://www.google.com/maps/search/?api=1&query=Behjadka+Niloha+Mawana+Meerut"
    const val ADMIN_EMAIL = "seemaanantom@gmail.com"

    val noticeCategories = listOf("Important", "Circular", "Holiday", "Exam", "Admission", "Event")
    val inquiryStatuses = listOf("submitted", "reviewed", "resolved")

    /**
     * Authentic baseline notices reflecting the portals and circulars published on njspublicschool.pages.dev.
     * Shown alongside real-time Firestore notices so visitors always see live portal notices immediately.
     */
    val portalBaselineNotices = listOf(
        Notice(
            id = "portal_baseline_1",
            authorId = "portal",
            authorName = "NJS Public School Portal",
            title = "Official Digital Portal, Circulars & Holiday Verification",
            description = "Students and parents can review school circulars, holiday verifications, and announcements published through the official NJS Public School portal at njspublicschool.pages.dev.",
            category = "Important",
            noticeDate = "Current Session",
            pinned = true,
            status = "published",
            attachmentUrl = PORTAL_URL,
            attachmentLabel = "Open njspublicschool.pages.dev",
            localBaseline = true
        ),
        Notice(
            id = "portal_baseline_2",
            authorId = "portal",
            authorName = "Admissions Desk",
            title = "Admissions Bulletin & Seat Availability Updates",
            description = "Enrollment guidelines, seat availability announcements, and admission updates are shared on the NJS Public School notice portal. Submit an admission inquiry in the Admissions section to connect with school administration.",
            category = "Admission",
            noticeDate = "Current Session",
            pinned = true,
            status = "published",
            attachmentUrl = PORTAL_URL,
            attachmentLabel = "View Admission Portal",
            localBaseline = true
        ),
        Notice(
            id = "portal_baseline_3",
            authorId = "portal",
            authorName = "Sports & Athletics Department",
            title = "400m Olympic Track Athletics, Cricket & Football Trials",
            description = "Track sprint heats, relay events, turf pitch cricket training, and floodlit football league sessions are active at the NJS Public School Sports Complex.",
            category = "Event",
            noticeDate = "Active Term",
            pinned = false,
            status = "published",
            localBaseline = true
        ),
        Notice(
            id = "portal_baseline_4",
            authorId = "portal",
            authorName = "Cultural & Excursion Committee",
            title = "Hastinapur Heritage Excursion & Fine Arts Workshops",
            description = "Supervised educational excursions to Hastinapur alongside terracotta clay sculpting, eco-friendly festival celebrations, and regular Havan moral mentoring sessions.",
            category = "Circular",
            noticeDate = "Active Term",
            pinned = false,
            status = "published",
            localBaseline = true
        )
    )

    val facilities = listOf(
        FacilityItem(
            title = "400m Olympic-Grade Running Track",
            subtitle = "All-Weather Athletics Complex",
            description = "Features a 400-meter Olympic-grade all-weather running track built for athletics training, sprint heats, and inter-house relay events alongside basketball courts.",
            highlights = listOf("400m All-Weather Track", "Sprint Heats & Relays", "Basketball Courts"),
            imageRes = R.drawable.img_sports_complex
        ),
        FacilityItem(
            title = "Cricket Academy & Turf Pitch",
            subtitle = "Professional Ground Training",
            description = "Dedicated cricket academy facilities on a manicured turf pitch supporting structured coaching, net practice, and competitive inter-school matches.",
            highlights = listOf("Turf Pitch Ground", "Structured Coaching", "Inter-School Fixtures"),
            imageRes = R.drawable.img_sports_complex
        ),
        FacilityItem(
            title = "Floodlit Football Turf",
            subtitle = "Evening & League Ready",
            description = "Floodlit football turf designed for tactical physical training, evening practice sessions, and inter-school tournaments.",
            highlights = listOf("Floodlit Turf", "Tactical Training", "League Tournaments"),
            imageRes = null
        ),
        FacilityItem(
            title = "Terracotta & Clay Sculpting Studio",
            subtitle = "Fine Arts & Tactile Craft",
            description = "Specialized fine arts and pottery spaces where students explore terracotta crafting, clay modeling, and creative festival art.",
            highlights = listOf("Terracotta Pottery", "Clay Sculpting", "Creative Workshops"),
            imageRes = R.drawable.img_arts_workshop
        ),
        FacilityItem(
            title = "Moral Mentoring & Havan Courtyard",
            subtitle = "Cultural & Spiritual Grounding",
            description = "Dedicated campus space supporting regular Havan ceremonies, spiritual reflection, and moral values education.",
            highlights = listOf("Regular Havan", "Moral Mentoring", "Cultural Grounding"),
            imageRes = R.drawable.img_hero_campus
        )
    )

    val academicPrograms = listOf(
        AcademicProgram(
            title = "Experienced Academic Mentorship",
            badge = "Faculty & Classrooms",
            description = "Experienced educators guide students through interactive, inspiring classroom environments designed to build critical thinking and deep conceptual clarity."
        ),
        AcademicProgram(
            title = "Holistic Values & Cultural Grounding",
            badge = "Character Education",
            description = "Academic learning is balanced with traditional values, regular Havan sessions, moral mentoring, and community responsibility."
        ),
        AcademicProgram(
            title = "Modern Digital & Circular Portal",
            badge = "Digital Ecosystem",
            description = "Digital infrastructure supporting transparent circular distribution, holiday verifications, exam timetables, and real-time notice updates."
        ),
        AcademicProgram(
            title = "Co-Curricular Excellence",
            badge = "Sports & Fine Arts",
            description = "Integrated schedules connecting classroom academics with Olympic-track athletics, cricket and football academies, terracotta fine arts, and educational excursions."
        )
    )

    val events = listOf(
        EventItem(
            title = "Educational Excursion to Hastinapur",
            category = "Excursion",
            summary = "Curated faculty-supervised field trips to Hastinapur exploring historical antiquities, ancient heritage of the Kuru Empire, and sacred temples.",
            highlights = listOf("Historical Heritage", "Faculty Supervision", "Experiential Learning"),
            imageRes = R.drawable.img_hastinapur_excursion
        ),
        EventItem(
            title = "Eco-Friendly Diwali, Rangoli & Rakhi Crafting",
            category = "Cultural",
            summary = "Vibrant campus celebrations encouraging creativity and sustainability through traditional Rakhi crafting, Rangoli competitions, and eco-friendly Diwali festivities.",
            highlights = listOf("Eco-Friendly Celebrations", "Rangoli Competitions", "Rakhi Workshops"),
            imageRes = R.drawable.img_arts_workshop
        ),
        EventItem(
            title = "Earth Day Environmental Projects",
            category = "Environment",
            summary = "Hands-on student initiatives focused on environmental stewardship, campus greenery, and sustainable habits.",
            highlights = listOf("Eco Awareness", "Student Leadership", "Campus Projects"),
            imageRes = R.drawable.img_hero_campus
        ),
        EventItem(
            title = "Annual Gala, Convocation & Sports Championships",
            category = "Annual Event",
            summary = "Celebrating student achievements, athletics sprint finals on the 400m track, inter-school football leagues, and faculty-student community workshops.",
            highlights = listOf("Annual Gala & Convocation", "400m Track Finals", "Inter-School Leagues"),
            imageRes = R.drawable.img_sports_complex
        ),
        EventItem(
            title = "Havan & Moral Values Sessions",
            category = "Tradition",
            summary = "Regular campus Havan ceremonies and guided moral mentoring nurturing mindfulness, gratitude, and disciplined character.",
            highlights = listOf("Havan Ceremonies", "Moral Values", "Community Spirit"),
            imageRes = R.drawable.img_hero_campus
        )
    )

    val galleryPhotos = listOf(
        GalleryPhoto(
            id = "gal_campus",
            title = "NJS Public School Campus Courtyard",
            category = "Campus",
            caption = "Sunlit academic courtyard blending modern architecture with green campus walkways.",
            imageRes = R.drawable.img_hero_campus
        ),
        GalleryPhoto(
            id = "gal_sports",
            title = "400m Olympic Track & Turf Grounds",
            category = "Sports",
            caption = "All-weather 400m athletics track beside our cricket turf pitch and floodlit football field.",
            imageRes = R.drawable.img_sports_complex
        ),
        GalleryPhoto(
            id = "gal_arts",
            title = "Terracotta Pottery & Festive Art Workshop",
            category = "Arts & Festivals",
            caption = "Students creating terracotta clay crafts and eco-friendly rangoli art in campus workshops.",
            imageRes = R.drawable.img_arts_workshop
        ),
        GalleryPhoto(
            id = "gal_hastinapur",
            title = "Hastinapur Heritage Excursion",
            category = "Excursions",
            caption = "Faculty-supervised educational excursion exploring the historic monuments and temples of Hastinapur.",
            imageRes = R.drawable.img_hastinapur_excursion
        ),
        GalleryPhoto(
            id = "gal_crest",
            title = "NJS Public School Emblem",
            category = "Campus",
            caption = "The official NJS Public School crest symbolizing the torch of knowledge — Creator of Knowledge.",
            imageRes = R.drawable.img_school_crest
        )
    )
}
