package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.Notice
import com.example.data.model.SchoolInquiry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Context.njsSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "njs_school_settings"
)

data class CapturedVisitor(
    val id: String,
    val name: String,
    val enteredAt: String
)

data class WebsiteSyncMeta(
    val lastSyncTime: String = "",
    val lastSyncSuccess: Boolean = false,
    val alertsEnabled: Boolean = true
)

class ThemePreferencesRepository(private val context: Context) {
    private val darkModeKey = booleanPreferencesKey("dark_mode_enabled")
    private val activeVisitorNameKey = stringPreferencesKey("active_visitor_name")
    private val capturedVisitorsKey = stringPreferencesKey("captured_visitors_json")
    private val localInquiriesKey = stringPreferencesKey("local_inquiries_json")
    private val websiteNoticesKey = stringPreferencesKey("website_notices_json")
    private val seenWebsiteNoticeIdsKey = stringPreferencesKey("seen_website_notice_ids_json")
    private val lastWebsiteSyncTimeKey = stringPreferencesKey("last_website_sync_time")
    private val lastWebsiteSyncSuccessKey = booleanPreferencesKey("last_website_sync_success")
    private val websiteAlertsEnabledKey = booleanPreferencesKey("website_alerts_enabled")
    private val websiteSyncV3CleanedKey = booleanPreferencesKey("website_sync_v3_cleaned")

    val isDarkMode: Flow<Boolean?> = context.applicationContext.njsSettingsDataStore.data
        .map { prefs -> prefs[darkModeKey] }

    val activeVisitorName: Flow<String> = context.applicationContext.njsSettingsDataStore.data
        .map { prefs -> prefs[activeVisitorNameKey] ?: "" }

    val capturedVisitors: Flow<List<CapturedVisitor>> = context.applicationContext.njsSettingsDataStore.data
        .map { prefs -> parseVisitors(prefs[capturedVisitorsKey]) }

    val localInquiries: Flow<List<SchoolInquiry>> = context.applicationContext.njsSettingsDataStore.data
        .map { prefs -> parseInquiries(prefs[localInquiriesKey]) }

    val websiteNotices: Flow<List<Notice>> = context.applicationContext.njsSettingsDataStore.data
        .map { prefs ->
            parseWebsiteNotices(prefs[websiteNoticesKey]).filterNot { notice ->
                com.example.data.remote.WebsiteNoticeParser.isEmptyStatusText(
                    "${notice.title} ${notice.description}"
                )
            }
        }

    val websiteSyncMeta: Flow<WebsiteSyncMeta> = context.applicationContext.njsSettingsDataStore.data
        .map { prefs ->
            WebsiteSyncMeta(
                lastSyncTime = prefs[lastWebsiteSyncTimeKey] ?: "",
                lastSyncSuccess = prefs[lastWebsiteSyncSuccessKey] ?: false,
                alertsEnabled = prefs[websiteAlertsEnabledKey] ?: true
            )
        }

    suspend fun clearStaleWebsiteNoticesOnce() {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            if (prefs[websiteSyncV3CleanedKey] != true) {
                prefs.remove(websiteNoticesKey)
                prefs.remove(seenWebsiteNoticeIdsKey)
                prefs[websiteSyncV3CleanedKey] = true
            }
        }
    }

    suspend fun clearWebsiteNotices() {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs.remove(websiteNoticesKey)
            prefs.remove(seenWebsiteNoticeIdsKey)
        }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs[darkModeKey] = enabled
        }
    }

    suspend fun setWebsiteAlertsEnabled(enabled: Boolean) {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs[websiteAlertsEnabledKey] = enabled
        }
    }

    suspend fun areWebsiteAlertsEnabled(): Boolean {
        return context.applicationContext.njsSettingsDataStore.data
            .map { it[websiteAlertsEnabledKey] ?: true }
            .first()
    }

    suspend fun saveWebsiteSyncResult(
        notices: List<Notice>,
        success: Boolean
    ): List<Notice> {
        val syncedAtLabel = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val newlyDiscovered = mutableListOf<Notice>()

        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs[lastWebsiteSyncTimeKey] = syncedAtLabel
            prefs[lastWebsiteSyncSuccessKey] = success
            if (success) {
                val seenIds = parseStringSet(prefs[seenWebsiteNoticeIdsKey]).toMutableSet()
                notices.forEach { notice ->
                    if (notice.id.isNotBlank() && !seenIds.contains(notice.id)) {
                        newlyDiscovered.add(notice)
                        seenIds.add(notice.id)
                    }
                }
                // Keep seen IDs bounded while retaining active notices
                val activeIds = notices.map { it.id }.toSet()
                val retainedIds = (activeIds + seenIds).take(200).toSet()
                prefs[websiteNoticesKey] = serializeWebsiteNotices(notices)
                prefs[seenWebsiteNoticeIdsKey] = serializeStringSet(retainedIds)
            }
        }
        return newlyDiscovered
    }

    suspend fun captureVisitorName(rawName: String) {
        val cleanName = rawName.trim()
        if (cleanName.isEmpty()) return
        val timestamp = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())

        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs[activeVisitorNameKey] = cleanName
            val existing = parseVisitors(prefs[capturedVisitorsKey]).toMutableList()
            existing.add(
                0,
                CapturedVisitor(
                    id = UUID.randomUUID().toString(),
                    name = cleanName,
                    enteredAt = timestamp
                )
            )
            val trimmed = existing.take(100)
            prefs[capturedVisitorsKey] = serializeVisitors(trimmed)
        }
    }

    suspend fun selectExistingVisitor(name: String) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs[activeVisitorNameKey] = cleanName
        }
    }

    suspend fun clearActiveVisitor() {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs[activeVisitorNameKey] = ""
        }
    }

    suspend fun clearCapturedVisitors() {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            prefs.remove(capturedVisitorsKey)
        }
    }

    suspend fun addLocalInquiry(inquiry: SchoolInquiry) {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            val current = parseInquiries(prefs[localInquiriesKey]).toMutableList()
            current.add(0, inquiry)
            prefs[localInquiriesKey] = serializeInquiries(current.take(50))
        }
    }

    suspend fun deleteLocalInquiry(inquiryId: String) {
        context.applicationContext.njsSettingsDataStore.edit { prefs ->
            val current = parseInquiries(prefs[localInquiriesKey])
                .filterNot { it.id == inquiryId }
            prefs[localInquiriesKey] = serializeInquiries(current)
        }
    }

    private fun parseVisitors(raw: String?): List<CapturedVisitor> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val name = obj.optString("name", "").trim()
                    if (name.isNotEmpty()) {
                        add(
                            CapturedVisitor(
                                id = obj.optString("id", i.toString()),
                                name = name,
                                enteredAt = obj.optString("enteredAt", "")
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeVisitors(list: List<CapturedVisitor>): String {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("enteredAt", item.enteredAt)
                }
            )
        }
        return arr.toString()
    }

    private fun parseInquiries(raw: String?): List<SchoolInquiry> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        SchoolInquiry(
                            id = obj.optString("id", "local_$i"),
                            userId = obj.optString("userId", "visitor"),
                            inquiryType = obj.optString("inquiryType", "contact"),
                            senderName = obj.optString("senderName", ""),
                            senderEmail = obj.optString("senderEmail", ""),
                            contactPhone = obj.optString("contactPhone", ""),
                            studentName = obj.optString("studentName", "").takeIf { it.isNotEmpty() },
                            gradeLevel = obj.optString("gradeLevel", "").takeIf { it.isNotEmpty() },
                            subject = obj.optString("subject", ""),
                            message = obj.optString("message", ""),
                            status = obj.optString("status", "submitted")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeInquiries(list: List<SchoolInquiry>): String {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("userId", item.userId)
                    put("inquiryType", item.inquiryType)
                    put("senderName", item.senderName)
                    put("senderEmail", item.senderEmail)
                    put("contactPhone", item.contactPhone)
                    put("studentName", item.studentName ?: "")
                    put("gradeLevel", item.gradeLevel ?: "")
                    put("subject", item.subject)
                    put("message", item.message)
                    put("status", item.status)
                }
            )
        }
        return arr.toString()
    }

    private fun parseWebsiteNotices(raw: String?): List<Notice> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val title = obj.optString("title", "").trim()
                    if (title.isNotEmpty()) {
                        add(
                            Notice(
                                id = obj.optString("id", "web_$i"),
                                authorId = obj.optString("authorId", "website"),
                                authorName = obj.optString("authorName", "NJS Website"),
                                title = title,
                                description = obj.optString("description", ""),
                                category = obj.optString("category", "Circular"),
                                noticeDate = obj.optString("noticeDate", "Latest"),
                                pinned = obj.optBoolean("pinned", false),
                                status = obj.optString("status", "published"),
                                imageUrl = obj.optString("imageUrl", "").takeIf { it.isNotEmpty() },
                                attachmentUrl = obj.optString("attachmentUrl", "").takeIf { it.isNotEmpty() },
                                attachmentLabel = obj.optString("attachmentLabel", "").takeIf { it.isNotEmpty() },
                                localBaseline = false
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeWebsiteNotices(list: List<Notice>): String {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("authorId", item.authorId)
                    put("authorName", item.authorName)
                    put("title", item.title)
                    put("description", item.description)
                    put("category", item.category)
                    put("noticeDate", item.noticeDate)
                    put("pinned", item.pinned)
                    put("status", item.status)
                    put("imageUrl", item.imageUrl ?: "")
                    put("attachmentUrl", item.attachmentUrl ?: "")
                    put("attachmentLabel", item.attachmentLabel ?: "")
                }
            )
        }
        return arr.toString()
    }

    private fun parseStringSet(raw: String?): Set<String> {
        if (raw.isNullOrBlank()) return emptySet()
        return try {
            val arr = JSONArray(raw)
            buildSet {
                for (i in 0 until arr.length()) {
                    val v = arr.optString(i, "").trim()
                    if (v.isNotEmpty()) add(v)
                }
            }
        } catch (_: Exception) {
            emptySet()
        }
    }

    private fun serializeStringSet(set: Set<String>): String {
        val arr = JSONArray()
        set.forEach { arr.put(it) }
        return arr.toString()
    }
}
