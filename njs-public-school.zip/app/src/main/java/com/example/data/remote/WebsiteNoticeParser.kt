package com.example.data.remote

import androidx.core.text.HtmlCompat
import com.example.data.model.Notice
import com.example.data.model.SchoolContentCatalog
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class WebsiteBackendHints(
    val rtdbUrls: Set<String> = emptySet(),
    val firestoreProjectIds: Set<String> = emptySet(),
    val scriptUrls: Set<String> = emptySet(),
    val apiUrls: Set<String> = emptySet()
)

object WebsiteNoticeParser {

    private val emptyStatusPhrases = listOf(
        "school is open",
        "स्कूल खुला",
        "no active",
        "no new notice",
        "no notice",
        "no notices",
        "no notification",
        "no notifications",
        "no announcements",
        "no announcement",
        "no circular",
        "no circulars",
        "no holiday",
        "no holidays",
        "no leave",
        "no update",
        "no updates",
        "0 notice",
        "zero notice",
        "nothing to show",
        "nothing posted",
        "none at the moment",
        "कोई नोटिस",
        "कोई छुट्टी",
        "operating normally",
        "regular schedule",
        "normal schedule",
        "all classes are open",
        "classes are open",
        "open today",
        "open tomorrow",
        "holiday verification",
        "ai school assistant",
        "ai assistant",
        "ask ai",
        "ask our ai",
        "creator of knowledge",
        "welcome to njs",
        "check back later",
        "stay tuned",
        "powered by",
        "copyright",
        "all rights reserved"
    )

    private val rtdbRegex = Regex(
        """https://[a-zA-Z0-9_-]+(?:-default-rtdb)?\.firebaseio\.com|https://[a-zA-Z0-9_-]+\.[a-z0-9-]+\.firebasedatabase\.app""",
        RegexOption.IGNORE_CASE
    )
    private val projectIdRegex = Regex(
        """["']?projectId["']?\s*[:=]\s*["']([a-zA-Z0-9-]+)["']"""
    )
    private val scriptSrcRegex = Regex(
        """<script[^>]+src\s*=\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE
    )
    private val apiUrlRegex = Regex(
        """["']((?:https?://[^"'\s]+|/[^"'\s]+)(?:notices\.json|notifications\.json|announcements\.json|/api/notices|/api/notifications))["']""",
        RegexOption.IGNORE_CASE
    )

    fun isEmptyStatusText(text: String): Boolean {
        val lower = text.trim().lowercase()
        if (lower.length < 4) return true
        return emptyStatusPhrases.any { lower.contains(it) }
    }

    fun discoverBackendHints(content: String, baseUrl: String): WebsiteBackendHints {
        val rtdb = rtdbRegex.findAll(content).map { it.value.trimEnd('/') }.toSet()
        val projectIds = projectIdRegex.findAll(content).map { it.groupValues[1] }.toSet()
        val scripts = scriptSrcRegex.findAll(content)
            .mapNotNull { resolveUrl(baseUrl, it.groupValues[1]) }
            .filter { it.startsWith(baseUrl) || it.contains("njspublicschool.pages.dev") }
            .toSet()
        val apis = apiUrlRegex.findAll(content)
            .mapNotNull { resolveUrl(baseUrl, it.groupValues[1]) }
            .toSet()
        return WebsiteBackendHints(
            rtdbUrls = rtdb,
            firestoreProjectIds = projectIds,
            scriptUrls = scripts,
            apiUrls = apis
        )
    }

    fun parseJsonNotices(rawJson: String, sourceUrl: String): List<Notice> {
        val trimmed = rawJson.trim()
        if (trimmed.isEmpty() || trimmed == "null" || trimmed == "{}" || trimmed == "[]") {
            return emptyList()
        }

        val parsed = mutableListOf<Notice>()
        try {
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    when (val item = arr.opt(i)) {
                        is JSONObject -> parseNoticeObject(item, null, sourceUrl)?.let { parsed.add(it) }
                        is String -> parsePlainNoticeString(item, sourceUrl)?.let { parsed.add(it) }
                    }
                }
            } else if (trimmed.startsWith("{")) {
                val root = JSONObject(trimmed)

                // Firestore REST API format: { "documents": [ { "name": "...", "fields": {...} } ] }
                if (root.has("documents") && root.opt("documents") is JSONArray) {
                    val docs = root.getJSONArray("documents")
                    for (i in 0 until docs.length()) {
                        val doc = docs.optJSONObject(i) ?: continue
                        parseFirestoreRestDoc(doc, sourceUrl)?.let { parsed.add(it) }
                    }
                    return parsed.distinctBy { it.id }
                }

                // Wrapped arrays: { notices: [...], notifications: [...], etc. }
                val wrapperKeys = listOf("notices", "notifications", "announcements", "circulars", "data", "items", "list")
                var foundWrapper = false
                for (key in wrapperKeys) {
                    val child = root.opt(key)
                    if (child is JSONArray) {
                        foundWrapper = true
                        for (i in 0 until child.length()) {
                            when (val elem = child.opt(i)) {
                                is JSONObject -> parseNoticeObject(elem, null, sourceUrl)?.let { parsed.add(it) }
                                is String -> parsePlainNoticeString(elem, sourceUrl)?.let { parsed.add(it) }
                            }
                        }
                    } else if (child is JSONObject) {
                        foundWrapper = true
                        parseRtdbMap(child, sourceUrl, parsed)
                    }
                }

                if (!foundWrapper) {
                    val single = parseNoticeObject(root, null, sourceUrl)
                    if (single != null) {
                        parsed.add(single)
                    } else {
                        parseRtdbMap(root, sourceUrl, parsed)
                    }
                }
            }
        } catch (_: Exception) {
            return emptyList()
        }

        return parsed.distinctBy { it.id }
    }

    /**
     * Parses only explicit structured notice embeds in HTML (<script id="school-notices-data" type="application/json">
     * or <meta name="school-notice">). Never scrapes generic HTML layout elements so static UI text cannot create false notices.
     */
    fun parseHtmlNotices(html: String, baseUrl: String): List<Notice> {
        val notices = mutableListOf<Notice>()

        val jsonScriptRegex = Regex(
            """<script[^>]+id\s*=\s*["']school-notices-data["'][^>]*>([\s\S]*?)</script>""",
            RegexOption.IGNORE_CASE
        )
        jsonScriptRegex.findAll(html).forEach { match ->
            notices.addAll(parseJsonNotices(match.groupValues[1], baseUrl))
        }

        val metaRegex = Regex(
            """<meta[^>]+name\s*=\s*["']school-notice["'][^>]+content\s*=\s*["']([^"']+)["']""",
            RegexOption.IGNORE_CASE
        )
        metaRegex.findAll(html).forEach { match ->
            val content = decodeHtmlEntities(match.groupValues[1]).trim()
            if (!isEmptyStatusText(content) && content.length >= 6) {
                notices.add(
                    Notice(
                        id = buildStableId(content),
                        authorId = "website",
                        authorName = "NJS Website",
                        title = content.take(100),
                        description = content,
                        category = inferCategory(content),
                        noticeDate = "Website Notice",
                        pinned = true,
                        status = "published",
                        attachmentUrl = baseUrl,
                        attachmentLabel = "Open Website"
                    )
                )
            }
        }

        return notices.distinctBy { it.id }
    }

    private fun parseRtdbMap(obj: JSONObject, sourceUrl: String, out: MutableList<Notice>) {
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val value = obj.opt(key)) {
                is JSONObject -> parseNoticeObject(value, key, sourceUrl)?.let { out.add(it) }
                is String -> parsePlainNoticeString(value, sourceUrl, key)?.let { out.add(it) }
            }
        }
    }

    private fun parseFirestoreRestDoc(doc: JSONObject, sourceUrl: String): Notice? {
        val fields = doc.optJSONObject("fields") ?: return null
        val docId = doc.optString("name", "").substringAfterLast('/').takeIf { it.isNotEmpty() }
        val flat = JSONObject()
        val keys = fields.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val vObj = fields.optJSONObject(k) ?: continue
            when {
                vObj.has("stringValue") -> flat.put(k, vObj.optString("stringValue"))
                vObj.has("booleanValue") -> flat.put(k, vObj.optBoolean("booleanValue"))
                vObj.has("integerValue") -> flat.put(k, vObj.optString("integerValue"))
                vObj.has("timestampValue") -> flat.put(k, vObj.optString("timestampValue"))
            }
        }
        return parseNoticeObject(flat, docId, sourceUrl)
    }

    private fun parsePlainNoticeString(rawText: String, sourceUrl: String, keyHint: String? = null): Notice? {
        val clean = rawText.trim()
        if (clean.length < 6 || isEmptyStatusText(clean)) return null
        val id = buildStableId(keyHint ?: clean)
        return Notice(
            id = id,
            authorId = "website",
            authorName = "NJS Website",
            title = clean.take(100),
            description = clean,
            category = inferCategory(clean),
            noticeDate = "Website Update",
            pinned = true,
            status = "published",
            attachmentUrl = sourceUrl,
            attachmentLabel = "Open Website",
            localBaseline = false
        )
    }

    private fun parseNoticeObject(obj: JSONObject, keyHint: String?, sourceUrl: String): Notice? {
        val status = obj.optString("status", "published").trim().lowercase()
        if (status == "draft" || status == "archived" || status == "deleted") return null
        if (obj.has("active") && !obj.optBoolean("active", true)) return null
        if (obj.has("published") && !obj.optBoolean("published", true)) return null
        if (obj.has("isOpen") && obj.optBoolean("isOpen", false) && !obj.has("title")) return null

        val rawTitle = firstNonEmpty(
            obj,
            "title", "heading", "subject", "name", "noticeTitle", "header", "alert"
        )
        val rawDesc = firstNonEmpty(
            obj,
            "description", "message", "body", "content", "text", "details", "notice", "summary"
        )

        val title = (rawTitle ?: rawDesc?.take(90) ?: "").trim()
        val description = (rawDesc ?: rawTitle ?: "").trim()

        if (title.length < 3 || description.length < 3) return null
        if (isEmptyStatusText("$title $description")) return null

        val rawDate = firstNonEmpty(
            obj,
            "noticeDate", "date", "publishedAt", "createdAt", "updatedAt", "timestamp", "time"
        )?.take(32) ?: "Website Update"

        val rawCategory = firstNonEmpty(obj, "category", "type", "tag")
        val normalizedCategory = SchoolContentCatalog.noticeCategories.firstOrNull {
            it.equals(rawCategory, ignoreCase = true)
        } ?: inferCategory("$title $description")

        val pinned = obj.optBoolean("pinned", false) ||
            obj.optBoolean("important", false) ||
            obj.optBoolean("isPinned", false) ||
            normalizedCategory == "Important"

        val imageUrl = firstNonEmpty(obj, "imageUrl", "image", "banner", "photo")
            ?.let { resolveUrl(SchoolContentCatalog.PORTAL_URL, it) }
        val attachmentUrl = firstNonEmpty(obj, "attachmentUrl", "attachment", "link", "url", "pdfUrl")
            ?.let { resolveUrl(SchoolContentCatalog.PORTAL_URL, it) }
            ?: sourceUrl
        val attachmentLabel = firstNonEmpty(obj, "attachmentLabel", "buttonText", "linkText")
            ?: "View on Website"

        val rawId = firstNonEmpty(obj, "id", "_id", "noticeId") ?: keyHint
        val id = if (!rawId.isNullOrBlank()) {
            "web_${rawId.replace(Regex("[^a-zA-Z0-9_-]"), "_")}"
        } else {
            buildStableId("$title|$description|$rawDate")
        }

        return Notice(
            id = id,
            authorId = "website",
            authorName = firstNonEmpty(obj, "authorName", "author", "postedBy") ?: "NJS Website",
            title = title.take(140),
            description = description.take(2000),
            category = normalizedCategory,
            noticeDate = rawDate,
            pinned = pinned,
            status = "published",
            imageUrl = imageUrl,
            attachmentUrl = attachmentUrl,
            attachmentLabel = attachmentLabel.take(120),
            localBaseline = false
        )
    }

    fun decodeHtmlEntities(input: String): String {
        return HtmlCompat.fromHtml(input, HtmlCompat.FROM_HTML_MODE_COMPACT).toString()
    }

    fun buildStableId(seed: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val hex = digest.take(8).joinToString("") { "%02x".format(it) }
        return "web_$hex"
    }

    fun inferCategory(text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("holiday") || lower.contains("closed") || lower.contains("leave") || lower.contains("छुट्टी") -> "Holiday"
            lower.contains("exam") || lower.contains("test") || lower.contains("result") || lower.contains("timetable") -> "Exam"
            lower.contains("admission") || lower.contains("enroll") || lower.contains("seat") -> "Admission"
            lower.contains("event") || lower.contains("excursion") || lower.contains("sport") || lower.contains("gala") -> "Event"
            lower.contains("urgent") || lower.contains("important") || lower.contains("alert") -> "Important"
            else -> "Circular"
        }
    }

    fun resolveUrl(baseUrl: String, candidate: String): String? {
        val c = candidate.trim()
        if (c.isEmpty() || c.startsWith("javascript:", ignoreCase = true) || c.startsWith("#")) return null
        return when {
            c.startsWith("http://") || c.startsWith("https://") -> c
            c.startsWith("//") -> "https:$c"
            c.startsWith("/") -> baseUrl.trimEnd('/') + c
            else -> baseUrl.trimEnd('/') + "/" + c
        }
    }

    private fun firstNonEmpty(obj: JSONObject, vararg keys: String): String? {
        for (k in keys) {
            val value = obj.optString(k, "").trim()
            if (value.isNotEmpty() && value != "null") return value
        }
        return null
    }
}
