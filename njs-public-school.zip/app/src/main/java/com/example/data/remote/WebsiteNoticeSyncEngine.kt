package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.data.model.Notice
import com.example.data.model.SchoolContentCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class WebsiteSyncResult(
    val notices: List<Notice>,
    val success: Boolean,
    val sourceUsed: String
)

class WebsiteNoticeSyncEngine(
    @Suppress("UNUSED_PARAMETER") private val context: Context? = null,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {
    private val portalUrl = SchoolContentCatalog.PORTAL_URL.trimEnd('/')

    private val commonJsonPaths = listOf(
        "/notices.json",
        "/notifications.json",
        "/announcements.json",
        "/data/notices.json",
        "/api/notices",
        "/api/notifications"
    )

    private val rtdbNoticeNodes = listOf(
        "/notices.json",
        "/notifications.json",
        "/announcements.json",
        "/alerts.json",
        "/school/notices.json"
    )

    private val firestoreCollections = listOf(
        "notices",
        "notifications",
        "announcements"
    )

    suspend fun syncFromWebsite(@Suppress("UNUSED_PARAMETER") allowWebViewFallback: Boolean = false): WebsiteSyncResult =
        withContext(Dispatchers.IO) {
            val collected = linkedMapOf<String, Notice>()
            var anyNetworkSucceeded = false
            var sourceLabel = "website"

            // 1. Fetch main portal HTML & check explicit structured embeds
            val mainHtml = fetchText(portalUrl)
            if (mainHtml != null) {
                anyNetworkSucceeded = true
                WebsiteNoticeParser.parseHtmlNotices(mainHtml, portalUrl).forEach {
                    collected[it.id] = it
                }
            }

            // 2. Discover backend hints (RTDB URLs, Firestore projectId, API JSON endpoints)
            val allHintsContent = StringBuilder()
            if (mainHtml != null) {
                allHintsContent.append(mainHtml).append('\n')
                val initialHints = WebsiteNoticeParser.discoverBackendHints(mainHtml, portalUrl)
                initialHints.scriptUrls.take(4).forEach { scriptUrl ->
                    fetchText(scriptUrl)?.let { jsText ->
                        allHintsContent.append(jsText).append('\n')
                    }
                }
            }

            val hints = WebsiteNoticeParser.discoverBackendHints(allHintsContent.toString(), portalUrl)

            // 3. Probe JSON endpoints & discovered API URLs on njspublicschool.pages.dev
            val candidateJsonUrls = (commonJsonPaths.map { "$portalUrl$it" } + hints.apiUrls).distinct()
            candidateJsonUrls.take(10).forEach { url ->
                val body = fetchText(url)
                if (body != null) {
                    val trimmed = body.trim()
                    if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                        anyNetworkSucceeded = true
                        val parsed = WebsiteNoticeParser.parseJsonNotices(trimmed, portalUrl)
                        if (parsed.isNotEmpty()) {
                            sourceLabel = "website-json"
                            parsed.forEach { collected[it.id] = it }
                        }
                    }
                }
            }

            // 4. Query any Firebase Realtime Database URL referenced by the website
            hints.rtdbUrls.take(3).forEach { rtdbBase ->
                rtdbNoticeNodes.forEach { node ->
                    val json = fetchText("$rtdbBase$node")
                    if (json != null) {
                        anyNetworkSucceeded = true
                        val parsed = WebsiteNoticeParser.parseJsonNotices(json, portalUrl)
                        if (parsed.isNotEmpty()) {
                            sourceLabel = "website-rtdb"
                            parsed.forEach { collected[it.id] = it }
                        }
                    }
                }
            }

            // 5. Query Firestore public REST API for any projectId discovered on the website
            hints.firestoreProjectIds.take(2).forEach { projectId ->
                firestoreCollections.forEach { col ->
                    val restUrl = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/$col?pageSize=30"
                    val json = fetchText(restUrl)
                    if (json != null) {
                        anyNetworkSucceeded = true
                        val parsed = WebsiteNoticeParser.parseJsonNotices(json, portalUrl)
                        if (parsed.isNotEmpty()) {
                            sourceLabel = "website-firestore"
                            parsed.forEach { collected[it.id] = it }
                        }
                    }
                }
            }

            WebsiteSyncResult(
                notices = collected.values.toList(),
                success = anyNetworkSucceeded,
                sourceUsed = sourceLabel
            )
        }

    private fun fetchText(url: String): String? {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("Cache-Control", "no-cache, no-store, must-revalidate")
                .header("Pragma", "no-cache")
                .header("User-Agent", "NJSPublicSchoolAndroid/1.0")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                response.body?.string()
            }
        } catch (e: Exception) {
            Log.d(TAG, "Fetch skipped for $url: ${e.message}")
            null
        }
    }

    private companion object {
        const val TAG = "WebsiteNoticeSyncEngine"
    }
}
