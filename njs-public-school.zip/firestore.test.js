const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "admin_uid_1";
const ADMIN_EMAIL = "seemaanantom@gmail.com";
const PARENT_ALICE_UID = "parent_alice_123";
const PARENT_BOB_UID = "parent_bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write notices or inquiries", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("notices").where("status", "==", "published").get()
  );
  await assertFails(
    unauthDb.collection("inquiries").where("userId", "==", PARENT_ALICE_UID).get()
  );
  await assertFails(
    unauthDb.collection("notices").doc("notice_1").set({
      authorId: ADMIN_UID,
      authorName: "Admin",
      title: "Unauthorized Notice",
      description: "Should fail",
      category: "Circular",
      noticeDate: "2026-11-16",
      pinned: false,
      status: "published",
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Verified admin can publish, update, and delete notices; spoofed unverified email is rejected", async () => {
  const adminDb = testEnv
    .authenticatedContext(ADMIN_UID, {
      email: ADMIN_EMAIL,
      email_verified: true,
    })
    .firestore();
  const spoofedDb = testEnv
    .authenticatedContext("spoof_uid", {
      email: ADMIN_EMAIL,
      email_verified: false,
    })
    .firestore();

  const now = new Date(Date.now() - 5000);

  await assertFails(
    spoofedDb.collection("notices").doc("notice_spoof").set({
      authorId: "spoof_uid",
      authorName: "Spoofer",
      title: "Spoofed Notice",
      description: "Must fail email_verified check",
      category: "Important",
      noticeDate: "2026-11-16",
      pinned: true,
      status: "published",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("notices").doc("notice_1").set({
      authorId: ADMIN_UID,
      authorName: "NJS Admin",
      title: "Annual Athletics Trials",
      description: "400m track trials begin this Friday at the sports complex.",
      category: "Important",
      noticeDate: "2026-11-16",
      pinned: true,
      status: "published",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Partial update succeeds; createdAt immutability enforced; @DocumentId `id` rejected
  await assertSucceeds(
    adminDb.collection("notices").doc("notice_1").update({
      title: "Updated Athletics Trials",
      pinned: false,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(
    adminDb.collection("notices").doc("notice_1").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  await assertFails(
    adminDb.collection("notices").doc("notice_with_id").set({
      id: "notice_with_id",
      authorId: ADMIN_UID,
      authorName: "NJS Admin",
      title: "Invalid ID key",
      description: "Should fail because @DocumentId id is disallowed in body",
      category: "Circular",
      noticeDate: "2026-11-16",
      pinned: false,
      status: "published",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Public signed-in visitors can query published notices, cannot read drafts or modify notices", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const ts = new Date(Date.now() - 10000);
    await db.collection("notices").doc("pub_1").set({
      authorId: ADMIN_UID,
      authorName: "NJS Admin",
      title: "Published Notice",
      description: "Public circular content.",
      category: "Circular",
      noticeDate: "2026-11-16",
      pinned: false,
      status: "published",
      createdAt: ts,
      updatedAt: ts,
    });
    await db.collection("notices").doc("draft_1").set({
      authorId: ADMIN_UID,
      authorName: "NJS Admin",
      title: "Draft Notice",
      description: "Internal draft content.",
      category: "Circular",
      noticeDate: "2026-11-16",
      pinned: false,
      status: "draft",
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const aliceDb = testEnv
    .authenticatedContext(PARENT_ALICE_UID, {
      email: "alice@example.com",
      email_verified: true,
    })
    .firestore();

  // Filtered published query matching NoticeRepository succeeds
  await assertSucceeds(
    aliceDb.collection("notices").where("status", "==", "published").get()
  );

  // Unfiltered list or direct draft read fails
  await assertFails(aliceDb.collection("notices").get());
  await assertFails(aliceDb.collection("notices").doc("draft_1").get());

  // Non-admin cannot create, update, or delete notices
  await assertFails(
    aliceDb.collection("notices").doc("pub_1").update({
      title: "Tampered Title",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(aliceDb.collection("notices").doc("pub_1").delete());
});

test("Inquiries enforce owner isolation, status integrity, and admin-only review updates", async () => {
  const aliceDb = testEnv
    .authenticatedContext(PARENT_ALICE_UID, {
      email: "alice@example.com",
      email_verified: true,
    })
    .firestore();
  const bobDb = testEnv
    .authenticatedContext(PARENT_BOB_UID, {
      email: "bob@example.com",
      email_verified: true,
    })
    .firestore();
  const adminDb = testEnv
    .authenticatedContext(ADMIN_UID, {
      email: ADMIN_EMAIL,
      email_verified: true,
    })
    .firestore();

  const now = new Date(Date.now() - 5000);

  // Alice creates valid admission inquiry
  await assertSucceeds(
    aliceDb.collection("inquiries").doc("inq_1").set({
      userId: PARENT_ALICE_UID,
      inquiryType: "admission",
      senderName: "Alice Sharma",
      senderEmail: "alice@example.com",
      contactPhone: "+91 9876543210",
      studentName: "Aarav Sharma",
      gradeLevel: "Class 6",
      subject: "Admission Inquiry 2026",
      message: "Requesting details on admission schedule and sports trials.",
      status: "submitted",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice cannot bypass status on create or include ghost field
  await assertFails(
    aliceDb.collection("inquiries").doc("inq_bad_status").set({
      userId: PARENT_ALICE_UID,
      inquiryType: "contact",
      senderName: "Alice Sharma",
      senderEmail: "alice@example.com",
      contactPhone: "+91 9876543210",
      subject: "Contact",
      message: "Trying to skip status.",
      status: "resolved",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice can query her own inquiries; unfiltered list fails
  await assertSucceeds(
    aliceDb.collection("inquiries").where("userId", "==", PARENT_ALICE_UID).get()
  );
  await assertFails(aliceDb.collection("inquiries").get());

  // Bob cannot read, list, update, or delete Alice's inquiry (PII isolation)
  await assertFails(bobDb.collection("inquiries").doc("inq_1").get());
  await assertFails(
    bobDb.collection("inquiries").doc("inq_1").update({
      subject: "Hijacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(bobDb.collection("inquiries").doc("inq_1").delete());

  // Admin can review and add adminReply
  await assertSucceeds(
    adminDb.collection("inquiries").doc("inq_1").update({
      status: "reviewed",
      adminReply: "Thank you. Please visit the school office or check the Admission bulletin.",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Terminal-state lock: Alice cannot edit after status becomes 'reviewed'
  await assertFails(
    aliceDb.collection("inquiries").doc("inq_1").update({
      message: "Editing after review",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Admins collection blocks client writes and cross-user reads", async () => {
  const aliceDb = testEnv.authenticatedContext(PARENT_ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("admins").doc(PARENT_ALICE_UID).set({ role: "admin" })
  );
  await assertFails(aliceDb.collection("admins").get());
});
